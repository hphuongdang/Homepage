%% Inpainting test for IBP-DL Algo

%N: number of data
%P: dimension of data
%Y: observed data

%sigma_noise_true: true noise level
%function simu_data create Data.
%function IBP3parameters_DL learns Dico when W is real
%function IBP3parameters_DL_Wbinaire_AGS learns when W is binairy

%ksvdbox: http://www.cs.technion.ac.il/~ronrubin/software.html
%The Indian Buffet Process: An Introduction and Review (Griffiths and Ghahramani 2011)
%%Written by Hong-Phuong DANG, hong_phuong.dang@ec-lille.fr

addpath('../util/')
%%
%clear all
close all

global H_Mask
global Y
global Yflag % variable for mask 
global N
global P


%% Painting image with a ratio
nameimage='boutbarbara.png';
IMin0=double(imread(['../Images/',nameimage])); %im2double
if max(max(IMin0))>1
    IMin0=IMin0/255; %Normaliser pour que images est entre 0 et 1
end
% % %%
sigma_noise_true=0;% Noise 5,10,15,20,25
ratioEteint=0.80; %Missing 0.8,0.5

index=randperm(numel(IMin0),round(numel(IMin0)*ratioEteint));
H_Mask=ones(size(IMin0));
H_Mask(index)=zeros;
%%
IMpainting=(IMin0+randn(size(IMin0))*sigma_noise_true/255).*H_Mask;

%% Initialisation
patchSize=8;
step=1;
%overlapping=0.5;
Yorig=ImaToPatches(IMpainting,patchSize,patchSize,step);
Y = Yorig;
[P,N]=size(Y);
if ratioEteint>0
    Yflag=ImaToPatches(H_Mask,patchSize,patchSize,step);
else
    Yflag=ones(P,N);
    H_Mask=ones(size(IMin0));
end




alpha=10;
sigma_noise=0.005;
%sigma_noise=sigma_noise_true*2/255;
sigmaD=1/sqrt(P);

setting.sampleAlpha=1; % 1: sample alpha, 0: don't sample alpha
setting.nb_iterMax=150;
setting.UpdateOption='DS'; %'DS' ou'DkSk'
%%
filenamedata=['Inpainting_',nameimage(1:end-4),'_Noise',num2str(sigma_noise_true),'_Mixing',num2str(ratioEteint*100)]
%% Learn Dico: IBP-DL
[DictSampled,CoefSampled,AlphaSampled,sigmaNoiseSampled,sigmaCoefSampled,lV,time]=IBP_DL_Inpainting_Denoising(sigma_noise,sigmaD,alpha,setting,filenamedata) ;
%[DictSampled,CoefSampled,AlphaSampled,sigmaNoiseSampled,sigmaCoefSampled,lV]=IBP_DL_Inpainting_Denoising_continue(DictSampled,CoefSampled,AlphaSampled,sigmaNoiseSampled,sigmaCoefSampled,lV,sigmaD,setting,filenamedata);




%% Inpainting


Yre=DictSampled{it}*CoefSampled{it};
K=size(DictSampled{end},2)


Iout=PatchesToIma(Yre,size(IMin0),patchSize,patchSize,step);

%%
Our_PSNR_inpainting=psnr(Iout,IMin0,1)

%%
save(filenamedata,'IMpainting','sigma_noise_true','ratioEteint','Iout','Our_PSNR_inpainting','DictSampled','CoefSampled','AlphaSampled','sigmaNoiseSampled','sigmaCoefSampled','lV','time','tauxacceptation' )
