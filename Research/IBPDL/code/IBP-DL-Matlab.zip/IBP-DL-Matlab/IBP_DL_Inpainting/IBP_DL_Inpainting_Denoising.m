function [DictSampled,CoefSampled,AlphaSampled,sigmaNoiseSampled,sigmaCoefSampled,lV,time]=IBP_DL_Inpainting_Denoising(sigmaY,sigmaD,alpha,setting,filenamedata)
%% Algo IBP-DL: Sample D, Z, S when there are noising missing data (inpainting)
% Sample Z-D-S-sigmaNoise-sigmaS-alpha
%
% setting.sampleAlpha is sample option for parameters of IBP: 1-Yes and 0-No
% setting.nb_iterMax is the number of maximum iteration 
%
% [1]: A BAYESIAN NON PARAMETRIC APPROACH TO LEARN DICTIONARIES WITH ADAPTED
% NUMBERS OF ATOMS,Dang and Chainais 2015
% [2]: Towards dictionaries of optimal size: a Bayesian non parametric
% approach, Dang and Chainais 2016
% [3]: INDIAN BUFFET PROCESS DICTIONARY LEARNING FOR IMAGE INPAINTING, Dang
% and Chainais 2016
%
%%Written by Hong-Phuong DANG, hong_phuong.dang@ec-lille.fr
global H_Mask
global Y
global Yflag
global N
global P


%% Initiliasation %%
nnzY=nnz(Yflag);
%ratioPixelActif=nnzY/numel(Yflag);
H_N=sum(1./(1:N));
CST=alpha*log(N);
%tauxacceptation(1)=1;
sigmaNoiseSampled(1)=sigmaY; %variance of Noize
varY=sigmaY^2;
gammaY=1/varY;

sigmaS=1; %variance of coeff
gammaS=1;

sigmaCoefSampled(1)=sigmaS;

varD=sigmaD^2;
gammaD=1/(varD);%constant



W = zeros(1,N);
K=1;

time(1,:)=[0,0];
CoefSampled{1}=W;
DictSampled{1}=(Y*W')/(W*W' + (sigmaY/sigmaD)^2 * eye(K) );
AlphaSampled(1)=alpha;

lV(1)=-(nnzY/2)*log(2*pi*varY)-sum(Y(:).^2)/(2*varY);


t=1;
compteur=0;


Y_Missing=1-Yflag;
nnzYflag=sum(Yflag);
while t<setting.nb_iterMax && K<500 && compteur < 5
    tic
    paramPoissonprior=alpha/N;
    K_new=poissrnd(paramPoissonprior,1,N);
    
    t=t+1;
    precD=gammaD*eye(K);
    %%%%%%W=full(W);
    invGD=cell(1,P);
    hD=zeros(P,K);
    
    for l=1:P
        yl_Missing=Y_Missing(l,:);
        Wl=W(:,~yl_Missing); %size K* number of actif pixels in dimension l
        gD=gammaY*(Wl*Wl')+precD;
        invGD{l}=eye(K)/gD;
        hD(l,:)=gammaY *Y(l,~yl_Missing)*Wl';
    end
    clear yl_Missing gD
    
    %% Sample Z %%
    %% InfererZ
    perm = randperm( N );
    %acceptation=0;
    for sample = 1:N %loop for the data   %while sample<=N
        i = perm( sample );
        if nnzYflag(i)==0 %to avoid a patch without information
            continue
        end
        yflagG=Yflag( : , i );
        yG = Y( : , i );
        wG = W( : , i );
        
        %removing the influence of data i in each dimension l
        wwT=wG*wG';
        hD=hD-gammaY*yG*wG';
        pAlume=find(yflagG==1); % index of actif pixels
        y_pAlume=yG(pAlume);
        muD=0*hD; %to avoid the value of muD trained with precedent data
        for l=pAlume'
            invgD=invGD{l};
            invgD=invgD - invgD*wwT*invgD/(wG'*invgD*wG-varY);
            muD(l,:)=hD(l,:)*invgD; %muD without influence of data i
            invGD(l)={invgD}; % covariance of D
        end
        
        m_i=sum(logical(W),2)-logical(W(:,i));
        atomesUsed=find(m_i~=0);
        
        for k=atomesUsed'
            lprior1 = log(m_i(k));
            lprior0 = log(N-m_i(k));
            
            %Log Likelihood
            %case zki=1
            if wG(k)==0
                wG( k )=randn*sigmaS;
            end
            %tmp=wG( k );
            wG1=wG;
            myG_pAlume1=muD(pAlume,:) * wG1; %myG=zeros(P,1); %myG(pAlume)=D(pAlume,:) * wG;
            syG_pAlume1=myG_pAlume1;
            
            %cas zki=0
            wG( k ) = 0;
            myG_pAlume0=muD(pAlume,:) * wG;
            syG_pAlume0=myG_pAlume0;
            o=1;
            
            %The myG_pAlume,syG_pAlume is the vectors of size of number of actif pixels of data i
            for l=pAlume'
                invgD=invGD{l};
                syG_pAlume1(o)=wG1'*invgD*wG1+varY;
                syG_pAlume0(o)=wG'*invgD*wG+varY;
                o=o+1;
            end
            
            %ll1 = -0.5*sum( log( sX )) - 0.5*((yG-myG).^2)./syG;
            ll1 = -0.5*sum( log( syG_pAlume1 ) +((y_pAlume-myG_pAlume1).^2)./syG_pAlume1) ;
            ll0 = -0.5*sum( log( syG_pAlume0 ) +((y_pAlume-myG_pAlume0).^2)./syG_pAlume0) ;
            
            zki=rand < 1 / ( 1 + exp( ( lprior0 + ll0 ) - ( lprior1 + ll1 ) ));
            if zki
                wG(k)=wG1(k);
            end   
        end
        clear wG1 myG_pAlume0 syG_pAlume0 myG_pAlume1 syG_pAlume1
        W(:,i)=wG;
        %% Add atoms
        singleton=find((wG~=0) & (m_i==0)); % find the singletons:  atoms where wG(k)~=0 and m_i(k)=0
        k_new_init=length(singleton);
        
        k_new_propo=K_new(i);
        if k_new_propo >0 || k_new_init >0
            
            %Calculate the likelihood with k_new_init
            if isempty(atomesUsed)
                myG_init=muD(pAlume,:) * wG;
                syG_init=myG_init;
                o=1;
                for l=pAlume'
                    invgD=invGD{l};
                    syG_init(o)=wG'*invgD*wG+varY;
                    o=o+1;
                end
                lZinit = -0.5*sum( log( syG_init ) +((y_pAlume-myG_init).^2)./syG_init ) ;
            else
                if zki
                    lZinit=ll1;
                else
                    lZinit=ll0;
                end
            end
            
            %Calculate the likelihood with k_new_propo
            wG_propo =wG;
            wG_propo( ~m_i ) = 0; %%remove (set to 0) the singletons
            snew_propo=randn(k_new_propo,1)*sigmaS;
            myG_propo=muD(pAlume,:) * wG_propo;%vector of size of the number of pixels actif of data i
            syG_propo=myG_propo;
            o=1;
            T=snew_propo'*snew_propo*varD + varY;
            for l=pAlume'
                invgD=invGD{l};
                syG_propo(o)=wG_propo'*invgD*wG_propo + T;
                o=o+1;
            end
            lZpropo= -0.5*sum( log( syG_propo ) +((y_pAlume-myG_propo).^2)./syG_propo) ;
            
            
            %Metropolis Hasting
            if  lZpropo-lZinit > log(rand) %log(1)=0
                %On accepte la proposition
                %acceptation=acceptation+1;
                Kold=size(wG,1);
                wG=[wG_propo; snew_propo];
                W(1:end+k_new_propo,i)=wG;
                invgDnew1= zeros(Kold,k_new_propo);
                invgDnew2 = [zeros(k_new_propo,Kold) eye(k_new_propo)*sigmaD^2];
                for l=1:P
                    invGD(l) = {[invGD{l} invgDnew1; invgDnew2 ]};%eye(k_new)*(1/sum(yflagG))];%
                end
                hD=[hD zeros(P,k_new_propo)];
            end
        %else k_new_propo >0 && k_new_init >0
            %acceptation=acceptation+1;
        end
        
        %recalculate occasionally  to avoid the accumulation of errors
        if mod( sample , 50 * CST ) == 0
            W(~sum(W,2),:)=[];% K*N
            K=size(W,1);
            %if K~=0
            precD=gammaD*eye(K);%K*K
            invGD=cell(1,P);
            hD=zeros(P,K);
            for l=1:P
                yl_Missing=Y_Missing(l,:);
                Wl=W(:,~yl_Missing); %size K* number of actif pixels in dimension l
                gD=gammaY*(Wl*Wl')+precD;
                invGD{l}=eye(K)/gD;
                hD(l,:)=gammaY *Y(l,~yl_Missing)*Wl';
            end
            clear yl_Missing dD
        else
            %Ajouter influence de data G
            wwT=wG*wG';
            hD=hD+gammaY*yG*wG';
            for l=pAlume'
                invgD=invGD{l};
                invGD(l)={invgD - invgD*wwT*invgD/(varY+wG'*invgD*wG)};
            end
        end
        
        
        
        
        
    end
    
    D=zeros(P,size(W,1));
    for l=1:P
        D(l,:)= hD(l,:) * invGD{l};
    end
    D(:,~sum(W,2))=[];
    W(~sum(W,2),:)=[];
    tZ=toc;
    
    
    clear invGD hD
    %% Sample D and S %%
    tic
    %    W=sparse(W);
    X_k = Y - Yflag.*(D*W); %X_k=diff
    %     if ratioPixelActif<0.6
    %         X_k=sparse(X_k);
    %         Yflag=sparse(Yflag);
    %     end
    Z=logical(W);
    K=size(W,1);
    %for tour=1:10
    
    if strcmp(setting.UpdateOption,'DS')==1
        for k=1:K
            zk=Z(k,:);
            wk=W(k,zk);
            % % % % %            if ratioPixelActif<0.6
            % % % % %                X_k(:,zk) = X_k(:,zk) + MultiSparse(Yflag(:,zk),D(:,k),W(k,zk));
            % % % % %            else
            X_k(:,zk) = X_k(:,zk)+ Yflag(:,zk).*(D(:,k)*wk);
            % % % % %            end
            
            %%%%Sample D
            sig_Dk = 1./(gammaY*Yflag(:,zk)*(wk'.^2)+P);
            mu_D = gammaY*sig_Dk.*(X_k(:,zk)*wk');
            D(:,k) = mu_D + randn(P,1).*sqrt(sig_Dk);
            
            X_k(:,zk) = X_k(:,zk)- Yflag(:,zk).*(D(:,k)*wk);
            
        end
        for k=1:K
            zk=Z(k,:);
            dk=D(:,k);
            X_k(:,zk) = X_k(:,zk)+ Yflag(:,zk).*(dk*W(k,zk));
            
            %%%%Sample S
            DTD = (dk.^2)'*Yflag;
            sigS1 = 1./(gammaS + gammaY*DTD(zk));
            W(k,:) = sparse(1,find(zk),randn(1,nnz(zk)).*sqrt(sigS1)+ sigS1.*(gammaY*( dk'*X_k(:,zk) )  ),1,N);
            
            
            X_k(:,zk) = X_k(:,zk)- Yflag(:,zk).*(dk*W(k,zk));
            
            
        end
        
    else %strcmp(setting.UpdateOption,'DkSk')==1  
        for k=1:K
            zk=Z(k,:);
            wk=W(k,zk);
            X_k(:,zk) = X_k(:,zk)+ Yflag(:,zk).*(D(:,k)*wk);
            
            %%%%Sample D
            sig_Dk = 1./(gammaY*Yflag(:,zk)*(wk'.^2)+P);
            mu_D = gammaY*sig_Dk.*(X_k(:,zk)*wk');
            D(:,k) = mu_D + randn(P,1).*sqrt(sig_Dk);
            
            %%%%Sample S
            DTD = (D(:,k).^2)'*Yflag;
            sigS1 = 1./(gammaS + gammaY*DTD(zk));
            W(k,:) = sparse(1,find(zk),randn(1,nnz(zk)).*sqrt(sigS1)+ sigS1.*(gammaY*( D(:,k)'*X_k(:,zk) )  ),1,N);
            
            X_k(:,zk) = X_k(:,zk)- Yflag(:,zk).*(D(:,k)*W(k,zk));
            
            
        end

    end
    
    if K>0 %&& setting.initW==0         
        %% sampleSigmaS
        sigmaS=SampleSigmaS(W,sigmaS,3);
        gammaS = 1/(sigmaS^2);  % K=size(W,1)
        
        %% sample alpha
        alpha=gamrnd(1 + K,1./(1 + H_N ));
    end

    
    %% sampleSigmaNoise
    sigmaY = SampleSigmaNoise(X_k,2,Yflag); %Jeyffrey
    varY=sigmaY^2;
    gammaY=1/varY;
    
    tDS=toc;
    lV(t)=-(nnzY/2)*log(2*pi*varY)-sum(X_k(:).^2)/(2*varY);
    clear Z X_k
    AlphaSampled(t)=alpha;
    DictSampled{t}=D;
    %CoefSampled{t}=W;
    CoefSampled{t}=sparse(W);
    %tauxacceptation(t)=acceptation/N;
    sigmaNoiseSampled(t)=sigmaY;
    sigmaCoefSampled(t)=sigmaS;
    time(t,:)=[tZ,tDS];
    
    if (mod(t,5)==0)
        disp(['iter:', num2str(t),  '   K:' ,num2str(K), '   sigmaBruit:' ,num2str(sigmaY),'   sigmaS:' ,num2str(sigmaS),'   alpha:' ,num2str(AlphaSampled(t-1))])
        save(filenamedata,'DictSampled','CoefSampled','AlphaSampled','sigmaNoiseSampled','sigmaCoefSampled','lV','time','H_Mask')
        if abs(lV(t)-lV(t-4))/lV(t-4)<0.005
            compteur=compteur+1;
        else
            compteur=0;
        end
    end
    
end
end


