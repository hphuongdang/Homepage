function [DictSampled,CoefSampled,AlphaSampled,NoiseSampled,sigmaDSampled,lV]=IBP_DL_Wbinary(sigmaY,sigmaD,alpha,setting,filenamedata)
%% Algo:IBP-DL for a matrix Coef binary.
% Sample Z-D-sigmaNoise-sigmaDict-alpha
%
% setting.sampleAlpha is sample option for parameters of IBP: 1-Yes and 0-No
% setting.nb_iterMax is the number of maximum iteration 
%
% [1]: The indian buffet process : An introduction and review, T. Griffiths and Z. Ghahramani.
% [2]: Accelerated sampling for the Indian buffet process, Doshi-Velez and
% Ghahramani, 2009
% [3]: Nonparametric Bayesian sparse factor models with application to gene
% expression modeling, Knowles and Ghahramani, 2011
%
% Written by Hong-Phuong DANG, hong_phuong.dang@ec-lille.fr

global Y
global N
global P
rng(0)
%% Initiliasation %%
H_N=sum(1./(1:N));
CST=alpha*log(N);
NoiseSampled(1)=sigmaY; %standard deviation of Noise
sigmaDSampled(1)=sigmaD; %standard deviation od Dico

W = zeros(1,N);
K=size(W,1);
D = (Y*W')/(W*W' + (sigmaY/sigmaD)^2 * eye(K) );
CoefSampled{1}=W;
DictSampled{1}=D;
AlphaSampled(1)=alpha;
Pdiv2=P/2;
varY=sigmaY^2;
gammaY=1/varY;
lV(1)=-(N*Pdiv2)*log(2*pi*varY)-sum(Y(:).^2)/(2*varY);  %<<< sum(Y(:).^2)


t=1;
compteur=0;
while  t<setting.nb_iterMax && K<700 %%compteur<2 &&
    % W=full(W);
    t=t+1;
    parameterPoisson= alpha/N;
    sigmaY=NoiseSampled(t-1);
    invM = W*W' + (sigmaY/sigmaD)^2 * eye(K) ;
    %information form
    gD = invM / varY ;  %gD = inv( sD ); % sD = varY *eye(K)/(W*W' + (sigmaY/sigmaD)^2 * eye(K) );
    hD = gammaY *Y*W';    %hD = muD /sD; % muD =Y*W'* eye(K)/(W*W' + (sigmaY/sigmaD)^2 * eye(K) )
    clear D
    
    %% Sample Z %%
    %% InfererZ
    gDinv = eye(K)/gD ;
    perm = randperm( N );  %Mix data ordering
    for sample = 1:N
        %lpriorPoisson=-alpha/sample+ (0:Kmax)*log(alpha/sample) -gammaln((0:Kmax)+1);%phuong
        i = perm( sample );
        yG = Y( : , i );
        wG = W( : , i );
        
        %removing the influence of data i
        % gD = gD - wG * wG' / varY;
        % hD= hD - yG/varY * wG';
        % muD = hD /gD;
        % sD = inv( gD);
        gDinv = gDinv - (gDinv*wG)*(wG'*gDinv)/(wG'*gDinv*wG-varY) ;
        hD= hD - yG/varY * wG';
        muD = hD * gDinv; % muD without influence of data i
        
        m_i=sum(logical(W),2)-logical(W(:,i));
        atomesUsed=find(m_i~=0); % mk_-i >0
        
        for k=atomesUsed'
            lprior1 = log(m_i(k));
            lprior0 = log(N-m_i(k));
            
            %Log Likelihood
            %case zki=1
            if wG(k)==0
                wG( k )=1;
            end
            mX = muD * wG ;
            sX = (wG' * gDinv) * wG + varY; %sX = wG' / gD * wG + varY;
            ll1 =  -Pdiv2 * log( sX ) - 1 / 2 / sX * sum(( yG - mX ).^2 );
            %cas zki=0
            wG( k ) = 0;
            mX = muD * wG ;
            sX = (wG' * gDinv) * wG + varY;
            ll0 = -Pdiv2 * log( sX )  - 1 / 2 / sX * sum(( yG - mX ).^2 );
            
            %Infer the value of zki
            if rand < 1 / ( 1 + exp( ( lprior0 + ll0 ) - ( lprior1 + ll1 ) ))
                wG(k)=1;
                W( k , i ) = 1;
            else
                %wG(k)=0;
                W( k , i ) = 0;
                
            end
        end
        
        %% Add atoms
        singleton=find((wG~=0) & (m_i==0)); % find the singletons:  atoms where wG(k)~=0 and m_i(k)=0
        k_new_init=length(singleton);
        
        k_new_propo=poissrnd(parameterPoisson); % same proposition
        
        if k_new_propo >0 || k_new_init >0
            mX_init = muD * wG;
            sX_init = (wG' * gDinv) * wG + varY;
            
            wG_propo =wG;
            wG_propo( singleton ) = 0; %remove (set to 0) the singletons
            %snew_propo=ones(k_new_propo,1); %propose new valeur of singletons
            mX_propo = muD * wG_propo;
            sX_propo=((wG_propo' * gDinv) * wG_propo + varY) + sigmaD^2*k_new_propo;
            
            %Metropolis Hasting
            lZpropo= -Pdiv2 * log( sX_propo ) - 1 / 2 / sX_propo * sum(( yG - mX_propo ).^2 );
            lZinit = -Pdiv2 * log( sX_init )  - 1 / 2 / sX_init  * sum(( yG - mX_init ).^2 );
            
            a=lZpropo-lZinit;
            if a >log(rand) %min(a,0) > log(rand)
                %k_new=k_new_propo;
                Kold=size(wG,1);
                %%gD=[gD zeros(Kold,k_new); zeros(k_new,Kold) eye(k_new)*1/(sigmaD^2)];
                W(singleton,i)=0; %remove initial singletons
                W(end+1:end+k_new_propo,i)=1; %mettre les proposition
                wG=W(:,i);
                gDinv = [gDinv zeros(Kold,k_new_propo); zeros(k_new_propo,Kold) eye(k_new_propo)*sigmaD^2];
                hD=[hD zeros(P,k_new_propo)];
                %else
                %k_new=k_new_init;
                
                %else
                %    k_new=0;
            end
        end
        
        
        %restore the influence od data i via matrix inversion lemma
        %%gD = gD + wG * wG' / varY;
        gDinv = gDinv - (gDinv*wG)*(wG'*gDinv) / (varY + wG'*gDinv*wG) ;
        hD = hD + (yG/varY) * wG';
        
        %recalculate occasionally
        if mod( sample , 50 * CST ) == 0
            W(~sum(W,2),:)=[];
            invM=(W*W' + (sigmaY/sigmaD)^2 * eye(size(W,1)) );
            %sD = varY * eye(size(W,1)) / invM;
            %D = 1/varY*(Y*W')*sD;
            gD = invM/varY;
            gDinv = inv(gD) ; % to avoid the accumulation of errors
            hD=gammaY *Y*W';
        end
        
    end
  
    
    W(~sum(W,2),:)=[];
    invM=(W*W' + varY / sigmaD^2 * eye(size(W,1)) );
    gD = invM/varY;
    gDinv = inv(gD) ; % to avoid the accumulation of errors
    D = 1/sigmaY^2*(Y*W')*gDinv;
    
    K=size(W,1);
    
    %% sample Noise
    X_diff=Y-D*W;
    %if setting.sampleNoise==1
    sigmaY = SampleSigmaNoise(X_diff,3);
    varY=sigmaY^2;
    gammaY=1/varY;
    %end
    
    %% sample variance Dict
    if  K>0 %&& setting.sampleSigmaD==1
        sigmaD=SampleSigmaD(D,sigmaD,2);
    end
    
    
    %% sample alpha
    if setting.sampleAlpha==1 && size(W,1)>0 %bonne parametre
        alpha=gamrnd(1 + size(W,1),1./(1 + H_N ));
%         if isnan(alpha)
%             keyboard
%         end
    end
    
    
    
    %% 
    DictSampled{t}=D;
    CoefSampled{t}=W;
    NoiseSampled(t)=sigmaY;
    sigmaDSampled(t)=sigmaD;
    AlphaSampled(t)=alpha;
    disp(['iter:', num2str(t), '   K:' ,num2str(K), '   sigmaY:' ,num2str(sigmaY),'   sigmaD:' ,num2str(sigmaD),'   alpha:' ,num2str(AlphaSampled(t)) ])
    lV(t)=-(N*Pdiv2)*log(2*pi*varY)-sum(X_diff(:).^2)/(2*varY);
    %if ( (mod(t,3)==0) || (mod(t,10)==0))
    save(filenamedata)
    %end
    if(mod(t,5)==0)
        if abs(lV(t)-lV(t-4))/lV(t-4)<0.005
            compteur=compteur+1;
        else
            compteur=0;
        end
    end
end

end
