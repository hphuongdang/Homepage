function [DictSampled,CoefSampled,AlphaSampled,NoiseSampled,SigmaCoefSampled,lV,time,t]=IBP_DL_Denoising(sigmaY,sigmaD,alpha,setting,filenamedata) 
%% IBP-DL for a matrix Coef real in the case of Denoising
%
% Sample Z-D-S-sigmaNoise-sigmaS-alpha
%
% setting.sampleAlpha is sample option for parameters of IBP: 1-Yes and 0-No
% setting.nb_iterMax is the number of maximum iteration 
%
% [1]:A BAYESIAN NON PARAMETRIC APPROACH TO LEARN DICTIONARIES WITH ADAPTED
% NUMBERS OF ATOMS,Dang and Chainais 2015
% [2]: Towards dictionaries of optimal size: a Bayesian non parametric
% approach, Dang and Chainais 2016
%
% Written by Hong-Phuong DANG, hong_phuong.dang@ec-lille.fr

global Y
global N
global P

%% Initiliasation 
H_N=sum(1./(1:N));
CST=alpha*log(N); 
NoiseSampled(1)=sigmaY; %standard deviation of Noize
sigmaS=1; %standard deviation of coeff
SigmaCoefSampled(1)=sigmaS;

time(1,:)=[0,0];
W = zeros(1,N);
K=size(W,1);
D = (Y*W')/(W*W' + (sigmaY/sigmaD)^2 * eye(K) );
CoefSampled{1}=W;
DictSampled{1}=D;
AlphaSampled(1)=alpha;
Pdiv2=P/2;
varY=sigmaY^2;
gammaY=1/varY;
varD=sigmaD^2;
lV(1)=-(N*Pdiv2)*log(2*pi*varY)-sum(Y(:).^2)/(2*varY);  %<<< sum(Y(:).^2)
tic

t=1;
compteur=0;
while  compteur<31 && t<setting.nb_iterMax && K<700 % convergence condition 
   % W=full(W);
    t=t+1;
    parameterPoisson= alpha/N;
    sigmaY=NoiseSampled(t-1);
    invM = W*W' + (sigmaY/sigmaD)^2 * eye(K) ;
    %information form
    gD = invM / varY ;  %gD = inv( sD ); % sD = varY *eye(K)/(W*W' + (sigmaY/sigmaD)^2 * eye(K) );
    hD=gammaY *Y*W';    %hD = muD /sD; % muD =Y*W'* eye(K)/(W*W' + (sigmaY/sigmaD)^2 * eye(K) )
    clear D
    
    %% Sample Z %%
    %% InfererZ
    gDinv = eye(K)/gD ;   
    perm = randperm( N );  %Mix data ordering
    for sample = 1:N
        %lpriorPoisson=-alpha/sample+ (0:Kmax)*log(alpha/sample) -gammaln((0:Kmax)+1);%phuong
        i = perm( sample );
        yG = Y( : , i );
        wG = W( : , i );
        
        %removing the influence of data i   
        % gD = gD - wG * wG' / varY;
        % hD= hD - yG/varY * wG';
        % muD = hD /gD;   
        % sD = inv( gD);
        gDinv = gDinv - (gDinv*wG)*(wG'*gDinv)/(wG'*gDinv*wG-varY) ;  % covariance of D 
        hD= hD - yG/varY * wG';
        muD = hD * gDinv; % muD without influence of data i
        
        m_i=sum(logical(W),2)-logical(W(:,i)); 
        atomesUsed=find(m_i~=0); % mk_-i >0
        
        for k=atomesUsed'           
            lprior1 = log(m_i(k)); 
            lprior0 = log(N-m_i(k));
            
            %Log Likelihood        
            %case zki=1
            if wG(k)==0
                wG( k )=randn*sigmaS;
            end
            tmp=wG( k );
            mX = muD * wG ;
            sX = (wG' * gDinv) * wG + varY; %sX = wG' / gD * wG + varY;
            ll1 =  -Pdiv2 * log( sX ) - 1 / 2 / sX * sum(( yG - mX ).^2 );
            %cas zki=0
            wG( k ) = 0;
            mX = muD * wG ;
            sX = (wG' * gDinv) * wG + varY;
            ll0 = -Pdiv2 * log( sX )  - 1 / 2 / sX * sum(( yG - mX ).^2 );
            
            %Infer the value of zki
            if rand < 1 / ( 1 + exp( ( lprior0 + ll0 ) - ( lprior1 + ll1 ) ))
                wG(k)=tmp;
                W( k , i ) = tmp;
            else
                %wG(k)=0; 
                W( k , i ) = 0;       
            end
        end

        %% Add atoms 
        singleton=find((wG~=0) & (m_i==0)); % find the singletons:  atoms where wG(k)~=0 and m_i(k)=0
        k_new_init=length(singleton);
            
            k_new_propo=poissrnd(parameterPoisson); % same proposition
                  
            if k_new_propo >0 || k_new_init >0
                mX_init = muD * wG;
                sX_init = (wG' * gDinv) * wG + varY;
                
                wG_propo =wG;
                wG_propo( singleton ) = 0; %remove (set to 0) the singletons
                snew_propo=randn(k_new_propo,1)*sigmaS; %propose new valeur of singletons
                mX_propo = muD * wG_propo;
                sX_propo=((wG_propo' * gDinv) * wG_propo + varY) + varD*sum(snew_propo.^2);
                        
                %Metropolis Hasting
                lZpropo= -Pdiv2 * log( sX_propo ) - 1 / 2 / sX_propo * sum(( yG - mX_propo ).^2 );
                lZinit = -Pdiv2 * log( sX_init )  - 1 / 2 / sX_init  * sum(( yG - mX_init ).^2 );
                
                a=lZpropo-lZinit;
                if a >log(rand) %min(a,0) > log(rand) 
                    %k_new=k_new_propo;
                    Kold=size(wG,1);
                    %%gD=[gD zeros(Kold,k_new); zeros(k_new,Kold) eye(k_new)*1/(varD)];
                    W(singleton,i)=0; %remove initial singletons
                    W(end+1:end+k_new_propo,i)=snew_propo; %mettre les proposition
                    wG=W(:,i);
                    gDinv = [gDinv zeros(Kold,k_new_propo); zeros(k_new_propo,Kold) eye(k_new_propo)*varD];
                    hD=[hD zeros(P,k_new_propo)];
                    %else
                    %k_new=k_new_init;
                    
                    %else
                    %    k_new=0;
                end
            end


        %restore the influence od data i via matrix inversion lemma
        %%gD = gD + wG * wG' / varY;
        gDinv = gDinv - (gDinv*wG)*(wG'*gDinv) / (varY + wG'*gDinv*wG) ; 
        hD = hD + (yG/varY) * wG';
        
        %recalculate occasionally      
        if mod( sample , 50 * CST ) == 0
            W(~sum(W,2),:)=[];
            invM=(W*W' + (sigmaY/sigmaD)^2 * eye(size(W,1)) );
            %sD = varY * eye(size(W,1)) / invM;
            %D = 1/varY*(Y*W')*sD;
            gD = invM/varY;
            gDinv = inv(gD) ; % to avoid the accumulation of errors
            hD=gammaY *Y*W';
        end
        
    end
     
    D = hD * gDinv ; %muD = hD /gD;
    D(:,~sum(W,2))=[];
    W(~sum(W,2),:)=[];
    tZ=toc;
    
    %% Sample D and S %%
    tic
    %W=sparse(W);
    X_k = Y - D*W; %X_k=diff
    Z=logical(W);
    K=size(W,1);
    %for Interneloop=1:10
        gammaS = 1/(sigmaS^2);  % K=size(W,1)
        for  k=1:K %k=size(W,1):-1:1
            %nnzk = nnz(Z(k,:));
            % if nnzk>0
            X_k(:,Z(k,:)) = X_k(:,Z(k,:)) + D(:,k)*W(k,Z(k,:));
            % end
                  
            %Sample D
            sig_Dk = 1/(gammaY*sum(W(k,Z(k,:)).^2)+P);
            mu_D = gammaY*sig_Dk* (X_k(:,Z(k,:))*W(k,Z(k,:))');
            D(:,k) = mu_D + randn(P,1)*sqrt(sig_Dk);
            
            DTD = sum(D(:,k).^2);
            
            %if nnzk>0
            %Sample S mais rendre Wk qui a une liaison avec Zk
            sigS1 = 1/(gammaS+ gammaY*DTD);
            W(k,:) = sparse(1,find(Z(k,:)),randn(1,nnz(Z(k,:)))*sqrt(sigS1)+ sigS1*(  gammaY*( D(:,k)'*X_k(:,Z(k,:)) )  ),1,N);
            %else
            %    W(k,:)  = 0;
            %end
            
            % if nnzk>0
            X_k(:,Z(k,:)) = X_k(:,Z(k,:))- D(:,k)*W(k,Z(k,:));
            %end
        end
        %% sample sigmaS
        if K>0
            sigmaS=SampleSigmaS(W,sigmaS,3); 
        end
        
        %% sample sigmaNoise
        sigmaY = SampleSigmaNoise(X_k,3); 
        varY=sigmaY^2;
        gammaY=1/(varY);
        
  %  end
    tDS=toc;
    %% sample alpha
    if setting.sampleAlpha==1 && size(W,1)>0 %bonne parametre
        alpha=gamrnd(1 + size(W,1),1./(1 + H_N ));
%         if isnan(alpha)
%             keyboard
%         end
    end
    AlphaSampled(t)=alpha;
    
  
    %%   
    lV(t)=-(N*Pdiv2)*log(2*pi*varY)-sum(X_k(:).^2)/(2*varY);
    clear Z X_k
    DictSampled{t}=D;
    CoefSampled{t}=sparse(W);
    NoiseSampled(t)=sigmaY;
    SigmaCoefSampled(t)=sigmaS;
    time(t,:)=[tZ,tDS];
    %disp(['iter:', num2str(t), ' timeZ:', num2str(tZ), ' timeDS:', num2str(tDS), '   K:' ,num2str(K), '   sigmaBruit:' ,num2str(sigmaY),'   sigmaS:' ,num2str(sigmaS),'   alpha:' ,num2str(Alpha(t-1)) ])  
    if (mod(t,5)==0)
    disp(['iter:', num2str(t), ' timeZ:', num2str(tZ), ' timeDS:', num2str(tDS), '   K:' ,num2str(K), '   sigmaBruit:' ,num2str(sigmaY),'   sigmaS:' ,num2str(sigmaS),'   alpha:' ,num2str(AlphaSampled(t-1)) ])  
    %disp(['iter:', num2str(t),' K:' ,num2str(K), ' sigmaY:' ,num2str(sigmaY),'  sigmaS:' ,num2str(sigmaS),'   alpha:' ,num2str(AlphaSampled(t-1)) ])
    end
  
    if (mod(t,5)==0)
    save(filenamedata)
    end
    if(mod(t,5)==0)
        if abs(lV(t)-lV(t-4))/lV(t-4)<0.005
            compteur=compteur+1;
        else
            compteur=0;
        end
    end
end

end


