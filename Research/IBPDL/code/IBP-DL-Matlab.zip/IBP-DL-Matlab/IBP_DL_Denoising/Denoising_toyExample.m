%% Simulation test for IBP-DL Algo 
%
%%Create Data
%N: number of data
%P: dimension of data
%Y: observed data
%parameterIBP: pararameters of IBP : alpha
%sigma_noise_true: true standard deviation of noise
%typeDico : 'RandomGaussian' or 'RandomBinary' or 'Binary4atoms'
%typeCoef : 'Real' or 'Binary'
%
%%Initialisation
%
%
%function DrawData create Data of toy example.
%function IBP_DL_Denoising learns Dico when W is real
%function IBP_DL_Wbinary learns Dico when W is binairy
%
%%Written by Hong-Phuong DANG, hong_phuong.dang@ec-lille.fr

addpath('../util/')

clear all
close all

global Y
global N
global P

%% Create Data
N=500;

parameterIBP=3;

sigma_noise_true=0.1;

typeDico='Binary4atoms';%typeDico='RandomGaussian'; % or 'RandomBinary' or 'Binary4atoms'

typeCoef='Binary'; %'Real' or 'Binary'

if strcmp (typeDico,'Binary4atoms')
    P=36; % example in gg11
else
    P=16;% 25, 36
end

sigma_dico=[];
sigma_coef=[];
if strcmp(typeDico,'RandomGaussian')
    sigma_dico=1/sqrt(P);
end
if strcmp(typeCoef,'Real')
    sigma_coef=1;
end
Data=DrawData(N,P,sigma_noise_true,parameterIBP,typeDico,typeCoef,sigma_dico,sigma_coef);

%% Initialisation
Yorig=Data.Ynoised;
Y = Yorig;
% for n=1:size(Y,2)
%     mY(n) = mean(Y(:,n)) ;
%     Y(:,n) = Y(:,n)-mY(n);
% end
[P,N]=size(Y);
filenamedata=['TestSimu_Dico',typeDico,'_Coef',typeCoef]; %
alpha=gamrnd(1,1);
sigma_noise=sigma_noise_true*2;

if strcmp(typeDico,'RandomGaussian')
    sigmaD=1/sqrt(P);
else
    sigmaD=1; % for the dico binary !!!!
end

setting.sampleAlpha=1; % 1: sample alpha, 0: don't sample alpha 
setting.nb_iterMax=1000;
%% Learn Dico: IBP-DL
if strcmp(typeCoef,'Real')
    [DictSampled,CoefSampled,AlphaSampled,sigmaNoiseSampled,lV,time,t]=IBP_DL_Denoising(sigma_noise,sigmaD,alpha,setting,filenamedata) ;
else   
    [DictSampled,CoefSampled,AlphaSampled,sigmaNoiseSampled,sigmaDict,lV]=IBP_DL_Wbinary(sigma_noise,sigmaD,alpha,setting,filenamedata);
end 
save(filenamedata)

%% Compare the dictionaries
ProjC = @(D,normD) D(:,normD>0) ./ repmat( sqrt(normD(normD>0)), [size(D,1), 1] );
D0 = ProjC(Data.Dict,sum((Data.Dict).^2)); 
D = ProjC(DictSampled{end},sum(DictSampled{end}.^2));

seuil=0.95 ; %correlation threshold

s=0; 
touch=[]; 
touch0=[];
clear signetmp
clear score
for q=1:size(D0,2)
    scoretmp = abs(D'*D0(:,q)) ;   
    [val, iret] = max(scoretmp) ;
    score(:,q) = scoretmp;
    if val>seuil
        s=s+1;
        touch(s) = iret;
        signetmp(s) = sign(D(:,iret)'*D0(:,q));
        touch0(s) = q ;
    end
end
fprintf('\n Nb of atoms retrieved : %d / %d parmi %d \n', length(unique(touch)),size(Data.Dict,2),size(D,2))

nb_retriev = length(unique(touch)) ;



%%
p = size(D0,1);

[liste indl] = unique(touch);
signD = repmat(signetmp(indl),size(D,1),1);
liste0 = touch0(indl);

if ~isempty(liste)
    figure(104)
    clf
    plot_dictionnary(D(:,liste),[],ceil(sqrt(p)));
    set(gcf,'Position',[200 700 256 256])
%     
%     nrj_X = sum(X(liste,:).^2,2);
%     [~, ord_atom] = sort(nrj_X,'descend');
%     Dord = D(:,liste(ord_atom)) ;
%     figure(105)
%     clf
%     plot_dictionnary(Dord,[],ceil(sqrt(p)));
%     title('Uniquely retrieved atoms')
%     set(gcf,'Position',[456 700 256 256])
else
    fprintf('\n No retrieval...\n')
end

%% compare atoms estimed considered as finded and reference atoms
figure(106)
clf
plot_dictionnary(D(:,liste).*signD,[],[4 5]);
set(gcf,'Position',[200,500 256 256])
figure(107)
clf
plot_dictionnary(D0(:,liste0),[],[4 5]);
set(gcf,'Position',[200+256,500 256 256])


