%% Denoising test for IBP-DL Algo
%
%N: number of data
%P: dimension of data
%Y: observed data
%sigma_noise_true: true noise level
%
% [1]:A BAYESIAN NON PARAMETRIC APPROACH TO LEARN DICTIONARIES WITH ADAPTED
% NUMBERS OF ATOMS,Dang and Chainais 2015
% [2]: Towards dictionaries of optimal size: a Bayesian non parametric
% approach, Dang and Chainais 2016
%
%%Written by Hong-Phuong DANG, hong_phuong.dang@ec-lille.fr

addpath('../util/')
%%
clear all
close all
global Y
global N
global P


%% Painting image with a ratio
nameimage='boutbarbara.png';
IMin0=double(imread(['../Images/',nameimage])); %im2double
if max(max(IMin0))>1
    IMin0=IMin0/255; %Normalisation of images between 0 and 1
end
sigma_noise_true=15;% Noise 10,15,20,25

IMnoising=IMin0+randn(size(IMin0))*sigma_noise_true/255;

%% Initialisation
patchSize=8;
%overlapping=0.5;
Yorig=ImaToPatches(IMnoising,patchSize,patchSize,1);

Y = Yorig;
for n=1:size(Y,2)
    mY(n) = mean(Y(:,n)) ;
    Y(:,n) = Y(:,n)-mY(n);
end

[P,N]=size(Y);

alpha=1;
%sigma_noise=0.005;
sigma_noise=sigma_noise_true*2/255;
sigmaD=1/sqrt(P);

setting.sampleAlpha=1; % 1: sample alpha, 0: don't sample alpha
setting.nb_iterMax=150;

filenamedata=['Dico_',nameimage(1:end-4),'_Noise',num2str(sigma_noise_true),'_FullData']
% Learn Dico: IBP-DL
[DictSampled,CoefSampled,AlphaSampled,sigmaNoiseSampled,SigmaCoefSampled,lV,time,t]=IBP_DL_Denoising(sigma_noise,sigmaD,alpha,setting,filenamedata) ;


%% Denoising

it=length(DictSampled)-20;
Yre=DictSampled{it}*CoefSampled{it};

for m=it+1:length(DictSampled)
    Yre=0.85*Yre+0.15*DictSampled{m}*CoefSampled{m};
end

for n=1:size(Y,2)
    Yre(:,n) = Yre(:,n)+mY(n);
end

K=size(DictSampled{end},2)
Iout_our_denoising=PatchesToIma(Yre,size(IMin0),patchSize,patchSize,1);
%psnr(Iout,IMin0,1)
Our_PSNR_denoising=[psnr(IMnoising,IMin0,1),psnr(Iout_our_denoising,IMin0,1)]




save(filenamedata,'N','P','IMin0','IMnoising','sigma_noise_true','Iout_our_denoising','Our_PSNR_denoising','DictSampled','CoefSampled','AlphaSampled','sigmaNoiseSampled','SigmaCoefSampled','lV','time','t')