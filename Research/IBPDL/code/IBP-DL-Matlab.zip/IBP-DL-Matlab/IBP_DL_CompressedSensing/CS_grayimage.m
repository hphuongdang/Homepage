%% Compressed sensing  test for IBP-DL Algo
%
%Y: observed data
%H: Matrix of projection 
%N: number of data
%q: dimension compressed of observed data 
%P: true dimension of data
%
% [1]: Towards dictionaries of optimal size: a Bayesian non parametric
% approach, Dang and Chainais 2016
% [2]: INDIAN BUFFET PROCESS DICTIONARY LEARNING FOR IMAGE INPAINTING, Dang
% and Chainais 2016
%
%%Written by Hong-Phuong DANG, hong_phuong.dang@ec-lille.fr

addpath('../util/')
%%
clear all
close all

global Y
global H
global N
global q
global P


%% Painting image with a ratio
% nameimage='castle';
% IMin0=double(imread(['../Images/',nameimage,'.png'])); %im2double
% IMin = .299*IMin0(:,:,1) + .587*IMin0(:,:,2) + .114*IMin0(:,:,3); %rgb2gray
 nameimage='boutbarbara';
 IMin=double(imread(['../Images/',nameimage,'.png'])); %im2double


%%
if max(max(IMin))>1
    IMin=IMin/255; %Normaliser pour que images est entre 0 et 1
end
%%
sigma_noise_true=0;% Noise 5,10,15,20,25
patchSize=8;
P=patchSize^2;
percentCS=0.5;
q=round(P*percentCS);
%H=eye(P); 
%H=H.*randn(P);
H=randn(q,P); 



%% Initialisation

Yorig=ImaToPatches(IMin,patchSize,patchSize,1);
Y = H*Yorig;
N=size(Y,2);

alpha=20;
%sigma_noise=sigma_noise_true*2;
sigma_noise=0.005;
sigmaD=1/sqrt(P);
%%
setting.sampleAlpha=1; % 1: sample alpha, 0: don't sample alpha
setting.nb_iterMax=300;

filenamedata=['Test_CS_',nameimage,'_','50','_FullData','normaliserAtome']
%% Learn Dico: IBP-DL
[DictSampled,CoefSampled,AlphaSampled,sigmaNoiseSampled,sigmaCoefSampled,lV]=IBP_DL_CS_prior(sigma_noise,sigmaD,alpha,setting,filenamedata);

save(filenamedata)


%% CS

it=50;%length(DictSampled)-25;
%
Yre=DictSampled{it}*CoefSampled{it};
%
  for m=it+1:length(DictSampled)
      Yre=0.85*Yre+0.15*DictSampled{m}*CoefSampled{m};
  end

%%
Iout=PatchesToIma(Yre,size(IMin),8,8,1);
%
Our_PSNR_cs=psnr(Iout,IMin,1)
%%
Iout1=Iout*mean(IMin(:)./Iout(:));
Our_PSNR_cs1=psnr(Iout1,IMin,1)


