function [DictSampled,CoefSampled,AlphaSampled,sigmaNoiseSampled,sigmaCoefSampled,lV]=IBP_DL_CS_prior(sigmaY,sigmaD,alpha,setting,filenamedata)
%% Algo Gibbs sampling of IBP-DL of compressed sensing
%
%Y: observed data (qxN)
%H: Matrix of projection (qxP) 
%N: number of data
%q: dimension compressed of observed data 
%P: true dimension of data
%
% [1]: Towards dictionaries of optimal size: a Bayesian non parametric
% approach, Dang and Chainais 2016
% [2]: INDIAN BUFFET PROCESS DICTIONARY LEARNING FOR IMAGE INPAINTING, Dang
% and Chainais 2016
%
%%Written by Hong-Phuong DANG, hong_phuong.dang@ec-lille.fr

global Y
global H
global N
global q
global P

%% Initiliasation %%
H_N=sum(1./(1:N));
sigmaNoiseSampled(1)=sigmaY; %variance of Noize
varY=sigmaY^2;
gammaY=1/varY;

sigmaS=1; %variance of coeff
gammaS=1;

sigmaCoefSampled(1)=sigmaS;

varD=sigmaD^2;
gammaD=1/(varD);%constant


HTH=H'*H;
HTY=H'*Y;

W = zeros(1,N);
K=size(W,1);
D = zeros(P,1);%(Y*W')/(W*W' + (NoiseSampled(1)/sigmaD)^2 * eye(K) );

CoefSampled{1}=W;
DictSampled{1}=D;
AlphaSampled(1)=alpha;

Nq=N*q;
lV(1)=-(Nq/2)*log(2*pi*varY)-sum(Y(:).^2)/(2*varY);


t=1;


while  t<setting.nb_iterMax && K<500
    t=t+1;
    paramPoissonprior=alpha/N;
    %% Sample Z %%
    
    perm = randperm( N );
    for sample = 1:N %loop for the data   %while sample<=N
        %% InfererZki
        i = perm( sample );
        yi = Y( : , i );%vector size q
        HTyi=HTY(:,i); %vector size P
        wi = W( : , i );
        m_i=sum(logical(W),2)-logical(W(:,i));
        atomesUsed=find(m_i~=0);
        
        for k=atomesUsed'
            
            dk=D(:,k);
            dHHd=dk'*HTH*dk;
            e_i_not_k=yi - H*D*wi;%vector size P
            tmp=wi( k );
            %if wi(k)==0
            if tmp==0
                tmp=randn*sigmaS; %w(k,i)=tmp
            else %tmp ~0
                e_i_not_k=e_i_not_k + H*dk*tmp;
            end
            
            lp1=log(m_i(k)) -0.5*gammaY *(tmp^2*dHHd - 2*tmp*dk'* H'*e_i_not_k)  ;
            lp0 = log(N-m_i(k));
            
            
            zki=rand < 1 / ( 1 + exp( lp0 - lp1 ));
            if zki
                sigmasik=1/(gammaY*dHHd+gammaS);
                musik=gammaY*sigmasik*dk'*H'*e_i_not_k ;
                tmp=randn*sqrt(sigmasik)+musik;
                if ~isreal(tmp)
                    disp(['Z_',num2str(k),'_',num2str(i), 'is not real'])
                    keyboard
                end
                wi(k)=tmp;
                %wi(k)=tmp;
            else
                wi(k)=0;
                
            end
        end
        W(:,i)=wi;
        Z=logical(W);
        D(:,~sum(Z,2))=[];
        W(~sum(Z,2),:)=[]; %% we delete wG(k)=0 &  m_i(k)=0
        
        
        %% Add atoms
        singleton=find((sum(logical(W),2)-logical(W(:,i))==0)); % find the singletons:  atoms where wG(k)~=0 and m_i(k)=0
        k_sing=length(singleton);
        k_propo=poissrnd(paramPoissonprior);
        if k_propo >0 || k_sing >0
            wi= W(:,i);
            e_i=yi-H*D*wi;
            lHsing=-0.5*gammaY*sum(e_i.^2);
            
            if k_sing >0
                Dsing=D(:,singleton);
                wi_sig=W(singleton,i);
                e_i = e_i+H*Dsing*wi_sig;
                e_i_notsig=e_i;
            else
                e_i_notsig=e_i;
                
            end
            
            if k_propo >0
                Dnew=randn(P,k_propo)*sigmaD;
                Dnew=Dnew./(ones(P,1)*sqrt(sum(Dnew.^2))); %<<<<<<ajouteer norme =1
                s_propo=randn(k_propo,1)*sigmaS; %proposal=prior
                e_i_notsig=e_i_notsig-H*Dnew*s_propo;
            else  %k_new_propo =0
                Wnew=[];
                Dnew=[];
            end
            
            %lZpropo=-sum(Ye_propo(:,i).^2)/(2*sigmaY^2);
            lHpropo=-0.5*gammaY*sum(e_i_notsig.^2);
            
            
            
            
            %Metropolis Hasting
            
            a=lHpropo-lHsing;
            if a>log(rand) %log(1)=0
                if k_propo>0
                    e_i_notsig=e_i_notsig+H*Dnew(:,1)*s_propo(1);
                    for knew=1:k_propo
                        dk=Dnew(:,knew);
                        dHHd=dk'*HTH*dk;
                        sigmasik=1/(gammaY*dHHd+gammaS);
                        musik=gammaY*sigmasik*dk'*H'*e_i_notsig;
                        tmp=randn*sqrt(sigmasik)+musik;
                        s_propo(knew)=tmp;
                        e_i_notsig=e_i_notsig-H*Dnew(:,knew)*s_propo(knew);
                    end
                    Wnew=zeros(k_propo,N);
                    Wnew(:,i)=s_propo;
                end
                W=[W;Wnew];
                W(singleton,:)=[];
                
                D=[D,Dnew];
                D(:,singleton)=[];
                
                %X_k=Ye_propo;
            end
        end
    end
    

    %% Sample D     
    W=sparse(W);
    E = Y - H*(D*W);
    Z=logical(W);
    K=size(W,1);
    for k=1:K
        E(:,Z(k,:)) = E(:,Z(k,:))+ H*(D(:,k)*W(k,Z(k,:)));
        gamma_Dk=gammaY*   sum(W(k,Z(k,:))'.^2) * HTH + gammaD*eye(P);
        sig_Dk = gamma_Dk\eye(P);
        mu_Dk=gammaY*sig_Dk* H'*(E(:,Z(k,:))* W(k,Z(k,:))');
        %         dk= mvnrnd(mu_Dk, sig_Dk);
        dk=mu_Dk+sqrtm(sig_Dk)*randn(P,1);
        D(:,k)=dk/norm(dk); 
        E(:,Z(k,:)) = E(:,Z(k,:))- H*(D(:,k)*W(k,Z(k,:)));
    end
    

    %% Sample SigmaNoise
    sigmaY = SampleSigmaNoise(E,2); %Jeyffrey
    varY=sigmaY^2;
    gammaY=1/varY;
    
    
    %% Sample sigmaS 
    if K>0
        sigmaS=SampleSigmaS(W,sigmaS,3); %Posteriori
    end
    gammaS = 1/(sigmaS^2);  % K=size(W,1)

    
    %% sample alpha
    if setting.sampleAlpha==1 && size(W,1)>0 %&& setting.initW==0
        alpha=gamrnd(1 + size(W,1),1./(1 + H_N ));
    end
    AlphaSampled(t)=alpha;
    lV(t)=-(Nq/2)*log(2*pi*varY)-sum(E(:).^2)/(2*varY);
    clear Z E
    DictSampled{t}=D;
    CoefSampled{t}=W;
    sigmaNoiseSampled(t)=sigmaY;
    sigmaCoefSampled(t)=sigmaS;
    
    if (mod(t,5)==0)
        disp(['iter:', num2str(t),  '   K:' ,num2str(K), '   sigmaBruit:' ,num2str(sigmaY),'   sigmaS:' ,num2str(sigmaS),'   alpha:' ,num2str(AlphaSampled(t-1))])
    end
    if ( (mod(t,5)==0))
        save(filenamedata)
    end
    %save(filenamedata)
    %end
end
end


