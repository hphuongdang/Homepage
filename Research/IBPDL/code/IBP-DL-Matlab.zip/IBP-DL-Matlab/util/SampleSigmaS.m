function sigmaS = SampleSigmaS(W,sigmaS,option)

%Sample sigmaS: standard deviation of the feature coefficient matrix
%
%W: the feature coefficient matrix
%option = 1 -> Maximum Likelihood
%option = 2 -> Jeffreys prior
%option = 3 -> Maximum-a-Posteriori with a prior non-informative
%Written by Hong-Phuong DANG, hong_phuong.dang@ec-lille.fr

KN=numel(W);
%When Zik=0, we consider that Sik=sigmaS (in the precedent iteration)
SUM_W=sum(sum(W.^2)) + (KN-nnz(W))*(sigmaS^2);

if option==1 %Maximum Likelihood
    w=reshape(W,1,KN);
    w(w==0)=[];
    w=[w,sigmaS*ones(1,KN-nnz(W))];
    gammaS=var(w);
elseif option==2 %Jeffreys prior
    gammaS=gamrnd(KN/2+2,2/SUM_W,1);
else %Maximum-a-Posteriori with a prior non-informative
    e0=10^-6;
    f0=10^-6;
    ei = e0 + 0.5*numel(W);
    fi = f0 + 0.5*SUM_W;
    gammaS = gamrnd(ei,1./fi);
end

sigmaS=1/sqrt(gammaS);

end