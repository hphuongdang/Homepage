function Y=ImaToPatches(Im,PatchSizeL,PatchSizeC,step)
%ImaToPatches extracts image into several patches with "sliding" mode, then rearranges patch into column.
%Y=ImaToPatches(Im,PatchSizeL,PatchSizeC,pas) 
%Im : Image
%PatchSizeL: height (row) of patch
%PatchSizeC: width (column) of patch
%step: the step for sliding
%
%Example:
%A=reshape([1:16],4,4)
%A =
%     1     5     9    13
%     2     6    10    14
%     3     7    11    15
%     4     8    12    16
%Y=ImaToPatches(A,2,2,2)
%Y =
%     1     3     9    11
%     2     4    10    12
%     5     7    13    15
%     6     8    14    16
%Written by Hong-Phuong DANG, hong_phuong.dang@ec-lille.fr

Y=zeros(PatchSizeL*PatchSizeC,floor((size(Im,2)-PatchSizeC)/step+1)*(floor((size(Im,1)-PatchSizeL)/step+1)));
c=1;
for j=1:step:size(Im,2)-PatchSizeC+1
    for i=1:step:size(Im,1)-PatchSizeL+1
       patch=Im(i:i+PatchSizeL-1,j:j+PatchSizeC-1);
       Y(:,c)=reshape(patch,PatchSizeL*PatchSizeC,1);
       c=c+1;
    end
end

end