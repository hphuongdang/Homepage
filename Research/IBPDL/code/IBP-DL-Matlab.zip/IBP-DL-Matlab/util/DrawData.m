function Data=DrawData(N,P,sigma_noise,parameterIBP,typeDico,typeCoef,sigma_D,sigma_S)
%% Draw Data Y=DW 
%N:number of data, P: dimension of data
%sigma_noise: standard deviation of noise
%parameterIBP: parameter of IBP  prior
%
%D is a dictionary with 4 options
%typeDico : 'Binary4atoms' or 'RandomBinary' or 'RandomGaussian'
%
%W is the coefficient matrix with 2 options
%typeCoef : 'Real' or 'Binary'
%When the option is 'Real' the prior of W is IBP-Gaussian 
%When the option is 'Binary' the prior of W is IBP
%
%sigma_D : standard deviation of dictionary
%sigma_S : standard deviation of feature coefficient matrix
%
%Data is a structure array
%Data.Dict: Dictionary matrix (binary or real)
%Data.W=W : Feature coefficient matrix (binary or real)
%Data.Ynet: initial data
%Data.Ynoised : data noising
%
%[1]:The Indian Buffet Process: An Introduction and Review (Griffiths and Ghahramani 2011)
%Written by Hong-Phuong DANG, hong_phuong.dang@ec-lille.fr
%% Create Z
Z=IBPprior(N,parameterIBP); %[1]
Z(~sum(Z,2),:)=[];

%% Create D
if strcmp(typeDico,'Binary4atoms')
    %%Dico like gg11 with 4 atoms
    while size(Z,1) < 4
        Z=IBPprior(N,parameterIBP);
    end
    [~, index]=sort(sum(Z,2),'descend');
    if size(Z,1) >= 10
        Z=Z(index(randi(10,1,4)),:);
    else
        Z=Z(index(randi(size(Z,1),1,4)),:);
    end
    Dict(1,:) = [ 0 1 0 0 0 0  1 1 1 0 0 0   0 1 0 0 0 0  0 0 0 0 0 0  0 0 0 0 0 0  0 0 0 0 0 0 ];
    Dict(2,:) = [ 0 0 0 0 0 0  0 0 0 0 0 0   0 0 0 0 0 0  1 1 1 0 0 0  1 0 1 0 0 0  1 1 1 0 0 0 ];
    Dict(3,:) = [ 0 0 0 1 1 1  0 0 0 0 1 1   0 0 0 0 0 1  0 0 0 0 0 0  0 0 0 0 0 0  0 0 0 0 0 0 ];
    Dict(4,:) = [ 0 0 0 0 0 0  0 0 0 0 0 0   0 0 0 0 0 0  0 0 0 1 0 0  0 0 0 1 1 1  0 0 0 1 0 0 ];
    Dict=Dict';
elseif strcmp(typeDico,'RandomBinary')
    %%For a binary random dictionary
    Dict=rand(P,size(Z,1))>0.6;
    %%For a random gaussian dictionary
elseif strcmp(typeDico,'RandomGaussian')
    Dict=randn(P,size(Z,1))*sigma_D;
else
    disp('Warning typeDico !!!')
end

%% Create W
if strcmp(typeCoef,'Real')
    S=randn(size(Z))*sigma_S; %Create S
    W=Z.*S; %like bernoulli gaussian
elseif strcmp(typeCoef,'Binary')
    W=Z;  % W is binary => Z
else
    disp('Warning typeCoef !!!')
end

%% Sample Data from D, W and noise
Data.Dict=Dict;
% Data.Z=Z;
% Data.S=S;
Data.W=W;
Data.Yinit=Dict*W; %Sample initial data
Noise=randn(P,N)*sigma_noise ; %sample gaussian noise with  mean = 0 and sigma_noise
Data.Ynoised=Data.Yinit+Noise; % add Noise into initial data
%Data.Ynoised=mvnrnd(Dict*W, ones(size(Dict,2),N)*var_bruit);
end



