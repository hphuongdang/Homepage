function Data=simu_data(N,P,sigma_noise,parameterIBP,typeDico,typeCoef,sigma_dict,sigma_S)
%% Sample Data
%N:number of data, P: dimension of data
%sigma_noise: standard deviation (ecart-type) !!!!!
%typeDico : 'Binary4atoms' or 'RandomBinary' or 'RandomGaussian'
%typeCoef : 'Real' or 'Binary'


%% Create Z
Z=priorIBP(N,parameterIBP);
Z(~sum(Z,2),:)=[];


%% Create D
if strcmp(typeDico,'Binary4atoms')
    %%Dico like gg11 with 4 atoms
    [~, index]=sort(sum(Z,2),'descend');
    Z=Z(index(randi(10,1,4)),:);
    Dict(1,:) = [ 0 1 0 0 0 0  1 1 1 0 0 0   0 1 0 0 0 0  0 0 0 0 0 0  0 0 0 0 0 0  0 0 0 0 0 0 ];
    Dict(2,:) = [ 0 0 0 0 0 0  0 0 0 0 0 0   0 0 0 0 0 0  1 1 1 0 0 0  1 0 1 0 0 0  1 1 1 0 0 0 ];
    Dict(3,:) = [ 0 0 0 1 1 1  0 0 0 0 1 1   0 0 0 0 0 1  0 0 0 0 0 0  0 0 0 0 0 0  0 0 0 0 0 0 ];
    Dict(4,:) = [ 0 0 0 0 0 0  0 0 0 0 0 0   0 0 0 0 0 0  0 0 0 1 0 0  0 0 0 1 1 1  0 0 0 1 0 0 ];
    Dict=Dict';
elseif strcmp(typeDico,'RandomBinary')
    %%Pour une dictionnaire random binaire
    Dict=rand(P,size(Z,1))>0.6;
    %%Pour une dictionnaire random normal
elseif strcmp(typeDico,'RandomGaussian')
    Dict=randn(P,size(Z,1))*sigma_dict;
else
    disp('Warning typeDico !!!')
end

%% Create W
if strcmp(typeCoef,'Real')
S=randn(size(Z))*sigma_S; %Cr�er S
    W=Z.*S;
elseif strcmp(typeCoef,'Binary')
    W=Z;  % W est binaire => Z
else
    disp('Warning typeCoef !!!')
end

%% Sample Data from D, W and noise
Data.Dict=Dict;
% Data.Z=Z;
% Data.S=S;
Data.W=W;
Data.Ynet=Dict*W; %g�n�rer les donn�es nettes
Noise=randn(P,N)*sigma_noise ; %g�n�rer la matrice de bruit de moyenne 0 et sigma_noise
Data.Ynoised=Data.Ynet+Noise;%ou tout simplement Xbruit=mvnrnd(Z*Dict, ones(N,size(Dict,2))*var_bruit);
end



