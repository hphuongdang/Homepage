function sigmaD=SampleSigmaD(D,sigmaD,option)

%Sample sigmaD: the standard deviation of dictionary
%
%D: Dictionary
%option = 1 -> Maximum Likelihood
%option = 2 -> Jeffreys prior
%option = 3 -> Maximum-a-Posteriori with a prior non-informative
%Written by Hong-Phuong DANG, hong_phuong.dang@ec-lille.fr

PK=numel(D);
if option==1 %Maximum Likelihood
    sigmaD=sqrt(var(reshape(D,1,PK)));
elseif option==2 %Jeffreys prior
    gammaD = gamrnd(PK/2+2,2/sum(sum(D.^2)),1);
    sigmaD = 1/sqrt(gammaD);
elseif option==3 %Maximum-a-Posteriori
    gi = 10e-6 + 0.5*PK;
    hi = 10e-6 + 0.5*sum(sum(D.^2));
    gammaD = gamrnd(gi,1./hi);
    sigmaD = 1/sqrt(gammaD);
end

end

