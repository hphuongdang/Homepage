function Iout=PatchesToIma(Y,sizeIm,PatchSizeL,PatchSizeC,step)
%PatchesToIma rearranges matrix columns into blocks, then restores an
%images from these blocks.
%Iout=PatchesToIma(Y,sizeIm,PatchSizeL,PatchSizeC,step) 
%Y: matrix columns
%sizeIm: vector of size of Image
%PatchSizeL: height (row) of patch
%PatchSizeC: width (column) of patch
%step: the step for sliding between 2 patches
%
%Example:
%A=reshape([1:16],4,4)
%A =
%     1     5     9    13
%     2     6    10    14
%     3     7    11    15
%     4     8    12    16
%Y=ImaToPatches(A,2,2,2)
%Y =
%     1     3     9    11
%     2     4    10    12
%     5     7    13    15
%     6     8    14    16
%A1=ImaToPatches(Y,[4 4]2,2,2)
%A1 =
%     1     5     9    13
%     2     6    10    14
%     3     7    11    15
%     4     8    12    16
%Written by Hong-Phuong DANG, hong_phuong.dang@ec-lille.fr

Iout=zeros(sizeIm);
Weight=zeros(sizeIm);
Yweight=ones(size(Y));
c=1;
for j=1:step:sizeIm(2)-PatchSizeC+1
    for i=1:step:sizeIm(1)-PatchSizeL+1
        Iout(i:i+PatchSizeL-1,j:j+PatchSizeC-1)=Iout(i:i+PatchSizeL-1,j:j+PatchSizeC-1)+reshape(Y(:,c),PatchSizeL,PatchSizeC);
%        patch=Im(i:i+PatchSizeL-1,j:j+PatchSizeC-1);
%        M(:,c)=reshape(patch,PatchSizeL*PatchSizeC,1);
        Weight(i:i+PatchSizeL-1,j:j+PatchSizeC-1)=Weight(i:i+PatchSizeL-1,j:j+PatchSizeC-1)+reshape(Yweight(:,c),PatchSizeL,PatchSizeC);
       c=c+1;
    end
end
Weight(Weight==0)=1;
Iout=Iout./Weight;
end
