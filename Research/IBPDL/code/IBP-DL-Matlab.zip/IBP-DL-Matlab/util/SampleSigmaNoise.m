function sigmaNoise = SampleSigmaNoise(E_Y,option,Yflag)

%Sample sigmaNoise: the standard deviation of noise
%
%E_Y: reconstruction error
%option = 1 -> Maximum Likelihood
%option = 2 -> Jeffreys prior
%option = 3 -> Maximum-a-Posteriori with a prior non-informative
%Written by Hong-Phuong DANG, hong_phuong.dang@ec-lille.fr

if nargin<3
    sumYflag = numel(E_Y);
else
    sumYflag = nnz(Yflag);
end

if option==1 %Maximum Likelihood
    x=reshape(E_Y,1,numel(E_Y));
    if nargin==3
        yflag=reshape(Yflag,1,numel(Yflag));
        x(~yflag)=[];
    end
    sigmaNoise=sqrt(var(x));
elseif option==2 %Jeffrey prior
    sigmaNoise = 1/sqrt(gamrnd(sumYflag/2+2,2/trace(E_Y*E_Y'),1));
else %Maximum-a-Posteriori
    c0= 10^-6;
    d0= 10^-6;
    ci = c0 + 0.5*sumYflag;
    di = d0 + 0.5*sum(sum((E_Y).^2));
    sigmaNoise=1/sqrt(gamrnd(ci,1./di));
end

end

