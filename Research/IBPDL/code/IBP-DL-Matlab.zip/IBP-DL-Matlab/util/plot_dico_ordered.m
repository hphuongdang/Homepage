function [Dord,Word]=plot_dico_ordered(D,W,L,C)
% plot_dico_ordered - display a dictionary sorted in decreasing order 
% w.r.t. their respective energy.
%   [Dord,Word]=plot_dico_ordered(D,W,L,C)
%   D: dictionary to display
%   W: matrix of coefficient 
%   L: number of rows to display
%   C: number of columns to display
%   Dord: dictionary sorted in decreasing order (columns)
%   Word: matrix of coefficient sorted in decreasing order (rows)
%   [Dord,Word]=plot_dico_ordered(D,W) display the dictionary with a number
%   of rows and columns adapted
%   
% Written by Hong-Phuong DANG, hong_phuong.dang@ec-lille.fr

K=size(D,2);
nrj_X = sum(W.^2,2);
%nrj_X = sum(logical(W),2);
[~, ord_atom] = sort(nrj_X,'descend');
Dord = D(:,ord_atom) ;
Word= W(ord_atom,:);
if nargin ==2
  if round(sqrt(K))^2<K
    plot_dictionnary(Dord,[],[round(sqrt(K)) round(sqrt(K))+1 ]);
  else
    plot_dictionnary(Dord,[],[round(sqrt(K)) round(sqrt(K)) ]);
  end  
else
    plot_dictionnary(Dord,[],[L C]);
end

end