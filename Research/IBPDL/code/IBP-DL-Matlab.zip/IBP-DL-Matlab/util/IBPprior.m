function Z=IBPprior(N,parameterIBP)
% IBPprior(N,parameterIBP) generate Z following the prior IBP with
% N : number of data
% parameterIBP : parameter of IBP prior
%
%gg11: The Indian Buffet Process: An Introduction and Review (Griffiths and Ghahramani 2011)
%Written by Hong-Phuong DANG, hong_phuong.dang@ec-lille.fr

% IBP(alpha)
%rng(6)
alpha=parameterIBP;
nbNew= zeros(1,N);

nbNew(1) = poissrnd(alpha);
if nbNew(1) >0
   Z = zeros(nbNew(1), N);
   Z(:, 1) = 1;
else
   Z=zeros(0,N); 
end

for i=2:N
    mk=sum(Z,2);
    p1=mk/i;
    u=rand(size(Z,1),1);
    Z(:,i)=(u<=p1);
    nbNew(i) = poissrnd(alpha/i);
    if nbNew(i) >0
        Znew = zeros(nbNew(i), N);
        Znew(:, i) = 1;
        Z = [Z; Znew];
    end
end

end