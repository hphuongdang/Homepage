#include<stdio.h>
#include<stdlib.h>
#include<getopt.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_rng.h>                                                      
#include <gsl/gsl_matrix.h>
#include <time.h>
#include"utils.h"

static void usage() {
	printf("Add noise and holes to a PNG file\n");
	printf("./png_to_noised_png -i input_file\n");
	printf("             	    -o output_file\n");
	printf("             	    -f output_mask_file\n");
	printf("             	    -m image mask describing holes (pure black and white, black are holes)\n");
	printf("             	    -r holes ratio (between 0 and 100 percent)\n");
	printf("             	    -n sigma of added gaussian noise\n");
	printf("             	    -P Giga Puddi !\n");
	exit(1);
}

int main( int argc, char **argv ) {

	char c;
	extern char * optarg; 

	char *input_file = NULL,
		 *output_file = NULL,
		 *output_mask_file = NULL,
		 *mask_file = NULL;
	int ratio = 0;
	int noise = 0;
	int puddi = 0;

	gsl_rng_env_setup();
	gsl_rng *r = gsl_rng_alloc(gsl_rng_mt19937);
	srand((unsigned) time(NULL));

	while ((c = getopt(argc , argv, "i:o:f:m:r:n:P")) != -1) {
		switch(c) {
			case 'i' : input_file = optarg; break;
			case 'o' : output_file = optarg; break;
			case 'f' : output_mask_file = optarg; break;
			case 'm' : mask_file = optarg; break;
			case 'r' : ratio = atoi(optarg); break;
			case 'n' : noise = atoi(optarg);break;
			case 'P' : puddi = 1;break;
			default : usage();
		}
	}

	if ( puddi ) {
		printf("Puddi puddi /°_°\\\n");
		exit(0);
	}

	if ( !input_file || !output_file )
		usage();
	if ( ratio && mask_file ) {
		printf("Can't use ratio and mask file both at the same time !\n");
		usage();
	}

	gsl_matrix *img = read_png_gray(input_file);
	gsl_matrix *mask_matrix;

	if( noise ) {
		gsl_matrix *noise_matrix = randn(r,noise, img->size1, img->size2);
		gsl_matrix_add (img, noise_matrix);
		gsl_matrix_free(noise_matrix);
	}

	if( mask_file ) {
		mask_matrix = read_png_gray(mask_file);
		gsl_matrix_scale (mask_matrix,1./255);

		gsl_matrix_mul_elements (img, mask_matrix);
		gsl_matrix_free(mask_matrix);
	} else if( ratio ){
		mask_matrix = gsl_matrix_calloc(img->size1,img->size2);
		// easier to put 1 in matrix of 0 instead of put everything to 1 and puts some 0
		int nb_keep = (int) ( (1 - (ratio / 100.0)) * (int) img->size1 * (int) img->size2 );
		int keep = 1;
		int *indexes = malloc(img->size1*img->size2*sizeof(int));
		for (int i=0; i<img->size1*img->size2; i++)
			indexes[i]=i;

		gsl_ran_shuffle (r, indexes, img->size1*img->size2, sizeof (int));

		for(int i=0; i<img->size1*img->size2; i++){
			gsl_matrix_set(mask_matrix, indexes[i] % img->size1, indexes[i] / img->size1, 1.0);
			keep++;
			if(keep == nb_keep)
				break;
		}
		free(indexes);
		gsl_matrix_mul_elements (img, mask_matrix);
		if( output_mask_file ) {
			gsl_matrix_scale (mask_matrix,255);
			export_to_png(mask_matrix, output_mask_file);
		}
		gsl_matrix_free(mask_matrix);
	}

	export_to_png(img, output_file);
	gsl_matrix_free(img);
	return 0;
}
