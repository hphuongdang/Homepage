#include <stdio.h>    
#include <stdlib.h>    
#include <unistd.h>    
#include <getopt.h>    
#include <math.h>                                                          
#include <gsl/gsl_matrix.h>            
#include <gsl/gsl_vector.h>   
#include <gsl/gsl_blas.h>  

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <sys/stat.h>
#include <string.h>
#include "utils.h"
#include "IBP_DL_Inpainting_Denoising.h"
size_t P, N;
gsl_matrix *Y;
gsl_matrix *Yflag;

static void usage() {
	printf("./main -i nb_iter\n");
	printf("       -y matrixY\n");
	printf("       -f matrixYflag\n");
	printf("       -d dico_out_file : output dico file ( not mandatory )\n");
	printf("       -c coeff_out_file : output coeff file ( not mandatory )\n");
	printf("       -o output_file : output PNG file ( not mandatory, needs -h and -w )\n");
	printf("       -t tmp_dir : Directory where temporary coef and dico will be stored.\n");
	printf("                    If not specified, tmp files will be written to out files.\n");
	printf("       -T tmp_save_interval : Interval to save temporary files (  default 5 ).\n");
	printf("       -I : Set this option to save temporary PNGs. not mandatory, needs -h and -w\n");
	printf("       -C : Set this option to save temporary coeffs. not mandatory.\n");
	printf("            If not set, save tmp coeff to coeff_out_file (if set)\n");
	printf("       -D : Set this option to save temporary dicos. not mandatory.\n");
	printf("       		If not set, save tmp dico to dico_out_file (if set)\n");
	printf("       -h height: the output PNG height\n");
	printf("       -w width : the output PNG width\n");
	printf("       -W patch_width ( defaults to 8 )\n");
	printf("       -H patch_height ( defaults to 8 )\n");
	printf("       -s step ( defaults to 1 )\n");
	exit(0);
}

void run_denoising_inpainting(int nb_iter, t_args args) {
	int i;
	gsl_matrix** tab_D = malloc( nb_iter * sizeof( gsl_matrix *)); 
  	double *Alpha = (double *)malloc(nb_iter* sizeof(double) );
  	double *SigmaNoise = (double *)malloc(nb_iter * sizeof(double) );
  	double *SigmaCoef = (double *)malloc(nb_iter * sizeof(double) );
 	
	int UpdateOption =1;

	printf("Loading %s...\n", args.Y_file);
	Y= readMatrix(args.Y_file);
	printf("Loading %s..\n", args.Yflag_file);
	Yflag= readMatrix(args.Yflag_file);

	if( args.save_tmp_imgs && args.tmp_save_dir) {
		mkdir(args.tmp_save_dir, S_IRWXU | S_IRWXG | S_IRWXO );
		char filename[256];

		gsl_matrix *orig = reconstitute_img_matrix(Y, args.img_w, args.img_h,
												   args.patch_w, args.patch_h, args.step);

		sprintf(filename, "%s/tmp_out_0.png", args.tmp_save_dir);
		export_to_png(orig, filename);
		gsl_matrix_free(orig);
	}


	P = Y->size1;
	N = Y->size2;
	printf("P= %zu \n",P);
	printf("N= %zu \n",N);
	double sigmaY= 0.005;
	int iter = 0;

	
	gsl_matrix* Coef;
	IBP_DL_Inpainting_Denoising( tab_D, &Coef, Alpha, SigmaNoise,
										   SigmaCoef, &iter, nb_iter, sigmaY,
										   UpdateOption, args); 
	
	if( args.dico_file )
		save_as_csv(tab_D[iter - 1], args.dico_file);
	if( args.coeff_file )
		save_as_csv(Coef, args.coeff_file);
	if (args.output_file)
		write_png_from_dico_and_coeff(Coef, tab_D[iter - 1],
									  args.img_w, args.img_h,
									  args.patch_w, args.patch_h, args.step,
									  args.output_file);

	printf("Save ok\n");

	for(i = 0; i < nb_iter; i++){
		gsl_matrix_free(tab_D[i]);
		
	}

	free(tab_D);

	free(Alpha);
	free(SigmaNoise);
	free(SigmaCoef);
	gsl_matrix_free(Coef);
	gsl_matrix_free(Y);
	gsl_matrix_free(Yflag);

}

int main(int argc, char **argv){
	int nb_iter = 5;
	char c;
	extern char * optarg; 
	
	t_args args = {
		.Y_file = NULL,
		.Yflag_file = NULL,
		.dico_file = NULL,
		.coeff_file = NULL,
		.tmp_save_dir = NULL,
		.output_file = NULL,
		.save_tmp_imgs = 0,
		.save_tmp_dico = 0,
		.save_tmp_coeff = 0,
		.tmp_save_interval = 5,
		.img_w = -1,
		.img_h = -1,
		.patch_w = 8,
		.patch_h = 8,
		.step = 1
	};

	while ((c = getopt(argc , argv, "i:y:f:d:c:t:T:h:w:W:H:s:o:ICD")) != -1) {
		switch(c) {
			case 'i' : nb_iter = atoi(optarg); break;
			case 'y' : args.Y_file = optarg; break;
			case 'f' : args.Yflag_file = optarg; break;
			case 'd' : args.dico_file = optarg; break;
			case 'c' : args.coeff_file = optarg; break;
			case 't' : args.tmp_save_dir = optarg; break;
			case 'T' : args.tmp_save_interval = atoi(optarg); break;
			case 'o' : args.output_file = optarg; break;
			case 'I' : args.save_tmp_imgs = 1; break;
			case 'D' : args.save_tmp_dico = 1; break;
			case 'C' : args.save_tmp_coeff = 1; break;
			case 'w' : args.img_h = atoi(optarg); break;
			case 'h' : args.img_w = atoi(optarg); break;
			case 'W' : args.patch_w = atoi(optarg); break;
			case 'H' : args.patch_h = atoi(optarg); break;
			case 's' : args.step = atoi(optarg); break;
			default : usage();
		}
	}

	if( !args.Y_file || !args.Yflag_file )
		usage();

	if( (args.output_file || args.save_tmp_imgs) && (args.img_w == -1 || args.img_h == -1))
		usage();

	if( args.save_tmp_imgs && ( !args.tmp_save_dir && !args.output_file ) )
		usage();

	run_denoising_inpainting(nb_iter, args);

	return(EXIT_SUCCESS);
}
