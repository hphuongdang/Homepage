#include<stdio.h>
#include<stdlib.h>
#include<getopt.h>

#include"utils.h"

static void usage() {
	printf("Convert a RGB PNG file into 3 grayscale PNG, one for each component.\n");
	printf("./split_rgb_png -i input_file\n");
	printf("                -r red_output_file\n");
	printf("                -g green_output_file\n");
	printf("                -b blue_output_file\n");
	exit(1);
}

int main( int argc, char **argv ) {
	char c;
	extern char * optarg; 

	char *input_file = NULL,
		 *red_output_file = NULL,
		 *green_output_file = NULL,
		 *blue_output_file = NULL;


	while ((c = getopt(argc , argv, "i:r:g:b:")) != -1) {
		switch(c) {
			case 'i' : input_file = optarg; break;
			case 'r' : red_output_file = optarg; break;
			case 'g' : green_output_file = optarg; break;
			case 'b' : blue_output_file = optarg; break;
			default : usage();
		}
	}

	if ( !input_file || !red_output_file  || !green_output_file || !blue_output_file )
		usage();

	gsl_matrix **img_components = read_png( input_file );

	if( !img_components[0] || !img_components[1] || !img_components[2] ) {
		printf("%s is not a RGB file\n", input_file);
		exit(1);
	}
	
	export_to_png(img_components[0], red_output_file);
	export_to_png(img_components[1], green_output_file);
	export_to_png(img_components[2], blue_output_file);


	gsl_matrix_free(img_components[0]);
	gsl_matrix_free(img_components[1]);
	gsl_matrix_free(img_components[2]);

	free(img_components);
	return 0;
}
