#ifndef __UTILS_H__
#define __UTILS_H__

#include <gsl/gsl_rng.h>
#include <gsl/gsl_matrix.h>                                                     
#include <gsl/gsl_vector.h>  

typedef enum {
	E_SUP = 0,
	E_INF,
	E_EQ,
	E_SUPEQ,
	E_INFEQ,
	E_DIF
} t_find_op;

/**
 * @brief Sum from 1/1 to 1/N;
 * @param N > 0
 * @returns a double
 * returns 0.0 if error
 */
double sum1divifrom1toN(size_t N); 


/**
 * @brief Random poisson
 * @param lambda Parameter of Poisson distribution
 * @param nb_lignes Number of rows of matrix Poisson
 * @param nb_colonnes Number of colums of  matrix Poisson
 * @returns a newly allocated matrix
 * returns NULL if error
 */
gsl_matrix *poissonrnd(gsl_rng *r,double lambda, size_t nb_lignes, size_t nb_colonnes);


/**
 * @brief Random Gaussian mean equal 0;
 * @param sigma standard deviation of Gaussian distribution
 * @param nb_lignes : number of rows of matrix Gaussian
 * @param nb_colonnes : number of colums of  matrix Gaussian
 * @returns a newly allocated matrix
 * returns NULL if error
 */
gsl_matrix *randn(gsl_rng *r,double sigma, size_t nb_lignes, size_t nb_colonnes);


/**
 * @brief Random Gaussian mean equal 0;
 * @param sigma standard deviation of Gaussian distribution
 * @param nb : number of elements of vector Gaussian
 * @returns a newly allocated vectors
 * returns NULL if error
 */
gsl_vector *randn_vect(gsl_rng *r, double sigma, size_t nb);


/**
* @brief Sums a matrix size L C
* @param M Matrix to sum
* @param option 1 to sum by Columns, 2 by lines
* @returns a newly allocated vector, size C  if option==1, size L if option == 2
* returns NULL if error
*/
gsl_vector *sumMatrix(gsl_matrix* M, int option);


/**
* @brief Sums all elements of a matrix 
* @param M Matrix to sum
* @returns a double 
* returns 0.0 if error
*/
double sumAllMatrix(gsl_matrix* M);


/**
* @brief Sums element non zeros a matrix size L C
* @param M Matrix to sum
* @param option 1 to sum by Columns, 2 by lines
* @returns a newly allocated vector, size C if option==1, size L if option == 2
* returns NULL if error
*/
gsl_vector *sumLogicalMatrix(gsl_matrix* M, int option) ;





gsl_vector* sumLogicalMatrix_FindNNZ(gsl_matrix* M, int option);


/**
* @brief Sums element non zeros a matrix size L C except ligne or column i
* @param M Matrix to sum
* @param i line or column not used to sum
* @param option 1 to sum by Columns, 2 by lines
* @returns a newly allocated vector, size C if option==1, size L if option == 2
* returns NULL if error
*/
gsl_vector *sumLogicalMatrixExceptOne(gsl_matrix* M, int option,size_t i);


/**
 * @brief Number not zeros in a matrix;
 * @param M : matrix
 * @returns r : number of element non-zeros in a matrix
 * returns 0 if not zero element
 */
int nnz_Matrix(gsl_matrix* M);


/**
 * @brief Number not zeros in a vector;
 * @param m : vector
 * @returns r : number of element non-zeros in a vector
 * returns 0 if not zero element
 */
int nnz_Vector(gsl_vector* m);  


/**
 * @brief Add new rows in a matrix;
 * @param m : m
 * @param nb_rows : number of row added
 * @returns matrix M adding rows 
 * returns 0 if not zero element
 */
gsl_matrix *matrix_add_rows( gsl_matrix *M, size_t nb_rows);

/**
 * @brief Extract columns vectors;
 * @param M : matrix M ;
 * @param index : index vector to extract
 * @returns matrix Msub 
 */
gsl_matrix *matrix_Extract_columns( gsl_matrix *M, gsl_vector* index  );

/**
 * @brief Extract rows vectors;
 * @param M : matrix M ;
 * @param index : index vector to extract
 * @returns matrix Msub 
 */
gsl_matrix *matrix_Extract_rows( gsl_matrix *M, gsl_vector* index  );


/**
 * @brief Extract elements in vector;
 * @param m : vector m ;
 * @param index : index vector to extract
 * @returns vector msub 
 */
gsl_vector *vector_Extract( gsl_vector *m, gsl_vector* index  );


/**
 * @brief find index i in vector m when m[i] option a;
 * @param m : vector m ;
 * @param option :  E_INF:< E_INFEQ:<= E_EQ:== E_SUPEQ:>= E_SUP:> 
 * @returns vector index
 */
gsl_vector* vector_find( gsl_vector *m, int option, double a );



/**
 * @brief find index i in vector m when m[i] option a and retur mEx[i] in v
 * @param m : vector m to compare,
 * @param mEx : vector mEx to extract,
 * @param option : E_INF:< E_INFEQ:<= E_EQ:== E_SUPEQ:>= E_SUP:> 
 * @returns vector v
 */
gsl_vector *vector_find_Extract( gsl_vector *m, gsl_vector *mEx, int option, double a );


/**
 * @brief inverse a matrix;
 * @param M: matrix M;
 * @returns matrix invM
 */
gsl_matrix *matrix_inverse( gsl_matrix* M);

double matrix_trace( gsl_matrix* M);

double matrix_square_trace( gsl_matrix* M);

gsl_matrix *readMatrix(const char *filename); 


int save_as_csv(gsl_matrix * M, char *filename);

gsl_matrix *matrix_add_cols( gsl_matrix *M, size_t nb_cols  );

void matrix_print(gsl_matrix *M);

void vector_print(gsl_vector *v);

gsl_matrix *reconstitute_img_matrix(gsl_matrix *Y_result,
										   int width,
										   int height,
										   int patch_w,
										   int patch_h,
										   int step) ;

void export_to_png(gsl_matrix *M, const char *path);
void export_to_rgb_png(gsl_matrix *r, gsl_matrix *g, gsl_matrix *b, const char *path);

void write_png_from_dico_and_coeff(gsl_matrix *C, gsl_matrix *D,
								   int width, int height,
								   int patch_w, int patch_h, int step,
								   const char *output_file);

gsl_matrix **read_png( const char *filename );
/** ----------------------------------------------------------------------------
 * returns a matrix of size w x h
 */
gsl_matrix *read_png_gray( const char *filename );

gsl_matrix *img_to_patches( const gsl_matrix *img, int patch_w, int patch_h, int step );

/** ----------------------------------------------------------------------------
 * img is of size w x h, not in 'patches' format.
 */
gsl_matrix *get_flags_gray( gsl_matrix *img);


/** ----------------------------------------------------------------------------
 * recale Im in interval [a b]
 */
gsl_matrix *matrix_rescale(gsl_matrix *Im, double a, double b);
#endif
