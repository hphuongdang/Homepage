#include<stdio.h>
#include<stdlib.h>
#include<getopt.h>

#include"utils.h"

static void usage() {
	printf("Process CSV Dico and Coeff files to PNG image\n");
	printf("usage : ./csv_to_png -c coeff_file\n");
	printf("                     -d dico_file\n");
	printf("                     -y patch_file ( incompatible with -d and -c )\n");
	printf("                     -o output_file\n");
	printf("                     -w width\n");
	printf("                     -h height\n");
	printf("                     -W patch_width ( defaults to 8 )\n");
	printf("                     -H patch_height ( defaults to 8 )\n");
	printf("                     -s step ( defaults to 1 )\n");
	exit(1);
}

int main( int argc, char **argv ) {
	char c;
	extern char * optarg; 

	char *dico_file = NULL,
		 *coeff_file = NULL,
		 *patch_file = NULL,
		 *output_file = NULL;

	int width = 0, height = 0;
	int patch_w = 8, patch_h = 8, step = 1;
	while ((c = getopt(argc , argv, "w:h:d:c:o:y:H:W:s:")) != -1) {
		switch(c) {
			case 'w' : width = atoi(optarg); break;
			case 'h' : height = atoi(optarg); break;
			case 'o' : output_file = optarg; break;
			case 'd' : dico_file = optarg; break;
			case 'c' : coeff_file = optarg; break;
			case 'y' : patch_file = optarg; break;
			case 'W' : patch_w = atoi(optarg); break;
			case 'H' : patch_h = atoi(optarg); break;
			case 's' : step = atoi(optarg); break;
			default : usage();
		}
	}

	if( dico_file && coeff_file && patch_file )
		usage();

	if( !patch_file && ( !dico_file || !coeff_file ) )
		usage();

	if ( !output_file )
		usage();

	if( coeff_file && dico_file ) {
		gsl_matrix *C = readMatrix( coeff_file );
		gsl_matrix *D = readMatrix( dico_file );

		write_png_from_dico_and_coeff(C, D, width, height, patch_w, patch_h, step, output_file);

		gsl_matrix_free(C);
		gsl_matrix_free(D);

	} else {
		gsl_matrix *flag_patch = readMatrix( patch_file );
		gsl_matrix *flag = reconstitute_img_matrix(flag_patch, width, height, patch_w, patch_h, step);
		
		export_to_png(flag, output_file);
	
		gsl_matrix_free(flag);
		gsl_matrix_free(flag_patch);

	}

	printf("Written to %s\n", output_file);
	return 0;
}
