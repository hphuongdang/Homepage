#include<stdio.h>
#include<stdlib.h>
#include<getopt.h>

#include"utils.h"

static void usage() {
	printf("Convert a PNG file into its patched matrix format. Can also try to extract the Yflag\n");
	printf("./pgn_to_csv -i input_file\n");
	printf("             -o output_file\n");
	printf("             -f output_flag_file : Extracted by considering black pixels as holes\n");
	printf("             -w : patch width ( defaults to 8 )\n");
	printf("             -h : patch height ( defaults to 8 )\n");
	printf("             -s : step ( defaults to 1 )\n");
	exit(1);
}

int main( int argc, char **argv ) {
	char c;
	extern char * optarg; 

	char *input_file = NULL,
		 *output_file = NULL,
		 *output_flag = NULL;

	int patch_w = 8, patch_h = 8, step = 1;

	while ((c = getopt(argc , argv, "i:o:f:w:h:s:")) != -1) {
		switch(c) {
			case 'i' : input_file = optarg; break;
			case 'o' : output_file = optarg; break;
			case 'f' : output_flag = optarg; break;
			case 'w' : patch_w = atoi(optarg); break;
			case 'h' : patch_h = atoi(optarg); break;
			case 's' : step = atoi(optarg); break;
			default : usage();
		}
	}

	if ( !input_file || !output_file )
		usage();

	gsl_matrix *img = read_png_gray(input_file);
	gsl_matrix *img_patch = img_to_patches(img, patch_w, patch_h, step);
	
	save_as_csv(img_patch, output_file);

	if( output_flag ) {
		gsl_matrix *flag = get_flags_gray(img);
		gsl_matrix *flag_patch = img_to_patches(flag, patch_w, patch_h, step);

		save_as_csv(flag_patch, output_flag);

		gsl_matrix_free(flag);
		gsl_matrix_free(flag_patch);
	}

	gsl_matrix_free(img);
	gsl_matrix_free(img_patch);

	return 0;
}
