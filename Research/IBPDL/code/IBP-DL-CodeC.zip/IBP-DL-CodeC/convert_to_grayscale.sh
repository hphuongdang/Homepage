#!/bin/sh
# Converts a PNG image to a grayscale image with 8bit scale.
# needs imagemagick.

img=$1;
img_out=$2;

if [ -z $img ]; then
	printf "Usage : ./convert_to_grayscale <image> [<image_out>]\n";
	printf "If image_out is ommited, the converted image overrites the original\n";
	exit;
fi

if [ -z $img_out ]; then
	img_out=$img;
fi

convert -colorspace Gray -depth 8 -alpha remove $img $img_out
