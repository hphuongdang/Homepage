#ifndef __FUNCTIONS_H__
#define __FUNCTIONS_H__

  #include <gsl/gsl_matrix.h>
  #include <gsl/gsl_vector.h>

extern gsl_matrix* Y ; 
extern gsl_matrix* Yflag ; 
extern size_t N;
extern size_t P;

void information_form(gsl_matrix** tab_invGD, gsl_matrix* hD ,gsl_matrix* W, double gammaY, gsl_vector **indexs_actif);


void remove_i_influence(gsl_matrix** tab_invGD, gsl_matrix* hD, gsl_matrix* muD, gsl_vector* l_Actif_of_i, gsl_vector* yi_Actif, 
						gsl_vector* yflag_i, gsl_vector* yi, gsl_vector* wi, double gammaY);


void restore_i_influence(gsl_matrix** tab_invGD, gsl_matrix* hD, 
 						gsl_vector* yi, gsl_vector* wi, gsl_vector* l_Actif,double gammaY);

void compute_for_MH(double* lZinit, double* lZprop, 
                    size_t K, size_t nb_singleton, size_t nb_prop, double sigmaS, double varY,
                    gsl_matrix** tab_invGD, gsl_matrix* muD,
                    gsl_vector* l_Actif_of_i, gsl_vector* yi_Actif, gsl_vector* wi,gsl_vector* wi_propo,gsl_vector* s_propo);


void inferZki (double *wki, double *lZinit,
			   gsl_rng *r, double mk_i, size_t k, gsl_vector *wG, double sigmaS,  double varY,
               gsl_matrix **tab_invGD, gsl_matrix *muD, gsl_vector *l_Actif_of_i, gsl_vector *yi_Actif);


double sumAllMatrixCoef(gsl_matrix* M, double sigmaS);

double SampleGammaS(gsl_rng *r, gsl_matrix* W, double sigmaS, int option);

double SampleGammaY(gsl_rng *r, gsl_matrix* E_Y, int option);


void Extrait_User_Of_k(gsl_matrix* Xk_sub, gsl_matrix* Yf_sub, gsl_vector* wk_sub,
					   gsl_matrix* X_k, gsl_vector* wk, gsl_vector* index);

void Copy_SubMatrix(gsl_matrix* X_k, 
					gsl_matrix* Xk_sub , gsl_vector* index);

gsl_vector *SampleDk(gsl_rng *r, gsl_matrix* Yf_sub, gsl_matrix* X_k_sub, gsl_vector* wk_sub ,double gammaY);

gsl_vector *SampleSk(gsl_rng *r, gsl_matrix* Yf_sub, gsl_matrix* X_k_sub, size_t nk, gsl_vector* dk ,double gammaY,double gammaS);

void Copy_2SubMatrix(gsl_matrix* X_k, gsl_matrix* W,
					gsl_matrix* Xk_sub , gsl_vector* wk_sub, gsl_vector* index, size_t k);
#endif
