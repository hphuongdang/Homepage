#ifndef __IBP_DL_INPAINTING_DENOISING_H__
#define __IBP_DL_INPAINTING_DENOISING_H__

#include <gsl/gsl_matrix.h>                                                     
#include <gsl/gsl_vector.h> 

typedef struct {
	char *Y_file;
	char *Yflag_file;
	char *dico_file;
	char *coeff_file;
	char *tmp_save_dir;
	char *output_file;
	int save_tmp_imgs;
	int save_tmp_dico;
	int save_tmp_coeff;
	int tmp_save_interval;
	int img_w;
	int img_h;
	int patch_w;
	int patch_h;
	int step;
} t_args;

extern gsl_matrix* Y ; 
extern gsl_matrix* Yflag ; 
extern size_t N;
extern size_t P;

void IBP_DL_Inpainting_Denoising(gsl_matrix** tab_D, gsl_matrix** Coef, double* Alpha, double* SigmaNoise, double* SigmaCoef, int *iter, int MaxIter, double sigmaY, int UpdateOption, t_args args);


#endif
