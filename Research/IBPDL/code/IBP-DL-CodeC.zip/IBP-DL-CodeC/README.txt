
INSTALL the numerical library GNU Scientific Library (GSL) : https://www.gnu.org/software/gsl/

Be careful : Version 1.16

////////////////////////
The code has been developed by Hong-Phuong DANG
hong_phuong.dang@ec-lille.fr or phuong dang.5988@gmail.com
Please email me if you found something wrong.

If you use in your research, please cite associated paper :
[1]Hong-Phuong Dang, Pierre Chainais. Indian Buffet Process Dictio- nary Learning for image inpainting. IEEE Workshop on Statistical Signal Processing (SSP), 2016 http://ieeexplore.ieee.org/document/7551729/
[2]Hong-Phuong Dang, Pierre Chainais. Towards dictionaries of opti- mal size : a Bayesian non parametric approach. Journal of Signal Processing Systems, 1-12, 2016 http://link.springer.com/article/10.1007/s11265-016-1154-1
[3]Hong-Phuong Dang, Pierre Chainais. A Bayesian non parametric approach to learn dictionaries with adapted numbers of atoms. Intel best paper award. IEEE 25th International Workshop on Machine Learning for Signal Processing (MLSP), 1–6, 2015. http://ieeexplore.ieee.org/document/7324348/
[4]Hong-Phuong Dang, Pierre Chainais. Approche bay ́esienne non pa- ram ́etrique dans l’apprentissage du dictionnaire pour adapter le nombre d’atomes. Conf ́erence Nationale GRETSI, 2015. https://hal.archives-ouvertes.fr/hal-01249821/


////////////////////////
TO START

make clean  : to delete .o
make all : To compile all

THEN : !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
For each experience: 

//////////////////////////////////////
Create the noising missing image : ./png_to_noised_png

GSL_RNG_SEED=$RANDOM  ./png_to_noised_png
-i the_name_of_image_input.png
-o the_name_of_image_output.png
-f the_name_of_mask_input.png
-r percentage_Missing_data 
-n noise_level

GSL_RNG_SEED=$RANDOM  ./png_to_noised_png -i barbara.png -o Painting_barbara.png -f Masque_barbara.png -r 80 -n 0

///////////////////////////////////////
Transfer image to patch
./png_to_csv 
-i the_name_of_observed_image_input.png
-o the_name_of_file_matrix_patches_output  (csv)
-w width_of_patch
-h length_of_patch
-s step_between_patches

./png_to_csv -i Masque_barbara.png  -o matrixYflag -w 8 -h 8 -s 1 
./png_to_csv -i Painting_barbara.png  -o matrixY -w 8 -h 8 -s 1 


//////////////////////////////////////
Inpainting with IBP-DL
 
time GSL_RNG_SEED=$RANDOM ./main 
-i number_of_iterations
-y name_of_file_of_MatrixY_patches_observed_image.csv
-f name_of_file_of_MatrixYflag_patches_mask.csv
-d name_of_output_file_Dico
-c name_of_output_file_Coef
-o name_output_inpainting_image.png (optional)
—w width_of_image -h length_of_image (required if -o or -I)
-t name_temporary_folder (optionnelle si -I -C -D)
-I : output restored image will saved in name_temporary_folder every 5 iterations (optional)
-C : output matrix Coeff will saved in name_temporary_folder every 5 iterations (optional)
-D : output matrix Dico will saved in name_temporary_folder every 5 iterations (optional)
-T number_of_step_of_iteration_to_save_temporaire (optional, default =5 if -I -C -D)


time GSL_RNG_SEED=$RANDOM ./main -i 200 -y matrixY.csv -f matrixYflag.csv -d Dico_barbara_80 -c Coef_barbara_80 -t ./tmp/ -I -C -D -w 512 -h 512


