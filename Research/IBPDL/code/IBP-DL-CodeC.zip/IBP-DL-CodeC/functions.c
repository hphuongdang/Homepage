#include <stdio.h>   
#include <stdlib.h>  
#include <math.h>                                                          
#include <gsl/gsl_matrix.h>    
#include <gsl/gsl_vector.h>                                                    
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_blas.h>
#include "utils.h"
#include "functions.h"

extern gsl_matrix* Y ; 
extern gsl_matrix* Yflag ; 
extern size_t N;
extern size_t P;



/*function [ invGD, hD ]  = information_form(W,gammaY)
% W : m taille KxN
% invGD : array taille P et chaque element dans array taille KxK
% hD : m taille PxK;

global Y
global Yflag
global P

K= size(W,1);
gammaD=P;
invGD=cell(1,P);
hD=zeros(P,K); %K va varier 

    for l=1:P
        index_actif=find(Yflag(l,:)==1); % v : 1x nb actif of dimension l
        Wl=W(:,index_actif); %m : K* nb actif of dimension l
        gD=gammaY*(Wl*Wl')+ gammaD*eye(K); % taille KxK
        invGD{l}=eye(K)/gD; % inverse matrix gD -> m : KxK
        hD(l,:)=gammaY *Y(l,index_actif)*Wl'; %v: 1xK
    end

end
*/
void information_form(gsl_matrix** tab_invGD, gsl_matrix* hD ,gsl_matrix* W, double gammaY, gsl_vector **indexs_actif)  {
	//sortie :gsl_matrix** tab_invGD, gsl_matrix* hD
	//gsl_matrix** tab_invGD, gsl_matrix* hD sont alloué déja dehors
	gsl_matrix* Wl;
	gsl_vector* index_actif;
	size_t K=W->size1;
	gsl_vector_view yl;
	gsl_vector_view hDl;
	gsl_vector *v = NULL;        
	gsl_matrix* gD=gsl_matrix_calloc(K,K);
	for (size_t l=0;l<P; l++){

		index_actif = indexs_actif[l];

		if( index_actif) {
			Wl= matrix_Extract_columns(W , index_actif);

			yl= gsl_matrix_row(Y,  l); // //Y(l,:) size N

			gsl_matrix_set_identity(gD);

			gsl_blas_dgemm(CblasNoTrans, CblasTrans, gammaY, Wl,Wl, (double)P, gD);

			gsl_matrix_free(tab_invGD[l]); // c pour libère dans le cas il il y qqch (recalculate occa)
			tab_invGD[l]= matrix_inverse(gD);

			hDl=gsl_matrix_row(hD,l);

			v = vector_Extract( &yl.vector , index_actif);
			gsl_blas_dgemv(CblasNoTrans, gammaY, Wl, v , 0.0, &hDl.vector);
			gsl_vector_free(v);
			gsl_matrix_free(Wl); 
		} else {
			gsl_matrix_set_identity(tab_invGD[l]);
			gsl_matrix_scale (tab_invGD[l], 1.0/(double) P );
		}
	}
	gsl_matrix_free(gD);
}

/*function [ invGD, hD, muD , l_Actif, yi_Actif]  = remove_i_influence(yflag_i, yi, wi,hD,invGD,gammaY)  
        %yi : v taille Px1
        %wi : v taille Kx1
        hD=hD-gammaY*(yflag_i.*yi)*wi'; %m : PxK
        muD=0*hD; % m: PxK
        l_Actif=[];
        yi_Actif=[];
        for l=1:P
        	if (yflag_i(l) ==1)
        		l_Actif=[l_Actif,l];
				yi_Actif=[yi_Actif, yi(l)];
            	invgD=invGD{l}; % m : KxK
            	invgD=invgD - invgD*(wi*wi')*invgD/(wi'*invgD*wi-1/gammaY);
            	muD(l,:)=hD(l,:)*invgD;  %muD(l,:) : v taille 1xK
            	invGD(l)={invgD}; % covariance of D
            end
        end
        
end*/

void remove_i_influence(gsl_matrix** tab_invGD, gsl_matrix* hD, gsl_matrix* muD, gsl_vector* l_Actif_of_i, gsl_vector* yi_Actif, 
						gsl_vector* yflag_i, gsl_vector* yi, gsl_vector* wi, double gammaY)
{	//Sorite: gsl_matrix** tab_invGD, gsl_matrix* hD, gsl_matrix* muD, gsl_vector* l_Actif_of_i, gsl_vector* yi_Actif: c'est init dehors 
	size_t K = hD->size2;
	size_t *pix = (size_t *)malloc(yi_Actif->size * sizeof(size_t) );
	size_t nb_elem = 0;
	size_t l;

    /*gsl_matrix *tMp = gsl_matrix_alloc(P, K); 
	gsl_blas_dger (gammaY, yi, wi, tMp); //gammaY*yi*wi'
	gsl_matrix_sub (hD, tMp);
	gsl_matrix_free(tMp);*/

    // A = \alpha x y^T + A 
    //gsl_blas_dger (alpha,  x,  y,  A)
    gsl_blas_dger (-1.0*gammaY, yi, wi, hD);//hD=hD-gammaY*yi*wi'; %m : PxK attention yi.*yflag_i=yi
	gsl_matrix* wiwiT = gsl_matrix_calloc(K,K);
	gsl_blas_dger (1.0, wi, wi, wiwiT); //wi*wi' : matrix KxK

	double wiT_invgD_wi=0.0;
	gsl_vector* invgDwi= gsl_vector_alloc (K);
	gsl_matrix* invgDwiwiT=gsl_matrix_alloc(K,K) ;
	gsl_matrix* invgd_Div_wiT_invgD_wi= gsl_matrix_alloc(K,K);
	

	gsl_vector_view view_hDl;
	gsl_vector_view view_muDl;

	for (l = 0; l < P; l++) {
		if ( gsl_vector_get(yflag_i,l) == 1.0){
			pix[nb_elem++] = l;
			//////// non on fait pas en C invgD=tab_invGD[l]; //invgD=invGD{l};

			//Begin : invgD=invgD - invgD*(wi*wi')*invgD/(wi'*invgD*wi-1/gammaY);
			//invgDwi = gsl_vector_calloc (K); // force à mettre tout à zeros

            //y = \alpha op(A) x + \beta y
            //gsl_blas_dgemv (TransA, alpha,  A,  x,  beta,  y)
			gsl_blas_dgemv (CblasNoTrans, 1.0, tab_invGD[l], wi, 0.0, invgDwi); //wi_invG=invgD*wi (vector)
			gsl_blas_ddot (invgDwi, wi, &wiT_invgD_wi); // wi'*invgD*wi;
			wiT_invgD_wi -= 1/gammaY; //wi'*invgD*wi-1/gammaY; scalaire
			
			//invgd_Div_wiT_invgD_wi = gsl_matrix_calloc(K,K);
			gsl_matrix_memcpy (invgd_Div_wiT_invgD_wi, tab_invGD[l]); //copy invgD dans invgd_Div_wiT_invgD_wi
			gsl_matrix_scale (invgd_Div_wiT_invgD_wi, 1.0/wiT_invgD_wi); //invgD/(wi'*invgD*wi-1/gammaY)
			
			//invgDwiwiT =  gsl_matrix_calloc(K,K);
			gsl_blas_dgemm (CblasNoTrans, CblasNoTrans, 1.0, tab_invGD[l], wiwiT, 0.0, invgDwiwiT); //invgD*(wi*wi')
			//////C = \alpha op(A) op(B) + \beta C///////
			//////gsl_blas_dgemm ( TransA,TransB,  alpha,  A, B, beta, gC) ////////
			gsl_blas_dgemm (CblasNoTrans, CblasNoTrans, -1.0, invgDwiwiT , invgd_Div_wiT_invgD_wi , 1.0, tab_invGD[l]); 
			//invgD= - invgD*(wi*wi') * invgD/(wi'*invgD*wi-1/gammaY) + invgD ;
			//invGD(l)={invgD}; % covariance of D
			//Fin: invgD=invgD - invgD*(wi*wi')*invgD/(wi'*invgD*wi-1/gammaY);

			view_hDl = gsl_matrix_row  (hD, l); // D(l,:)
			view_muDl = gsl_matrix_row  (muD, l); // muD(l,:) : v taille 1xK
			gsl_blas_dgemv (CblasNoTrans, 1.0, tab_invGD[l], &view_hDl.vector, 0.0, &view_muDl.vector); //muD(l,:)=hD(l,:)*invgD; 
			//gsl_matrix_set_row (muD, l, hDl_invgD); // 
            /*if (tab_invGD[l]->size1 != tab_invGD[l]->size2){
                printf(" faux 2\n");
            }*/
		}
	}
	for (l = 0; l < nb_elem; l++) { //on a déja bien allouer l_Actif_of_i et yi_Actif en bonne
		gsl_vector_set(l_Actif_of_i, l, (double) pix[l]);
		gsl_vector_set(yi_Actif,l, gsl_vector_get(yi, (double) pix[l]) );
	}
	free(pix);
	gsl_matrix_free(wiwiT);
	gsl_vector_free(invgDwi);
	gsl_matrix_free(invgd_Div_wiT_invgD_wi);
	gsl_matrix_free(invgDwiwiT);


}// pk un ?, à partir de 165 c'est apparait si ça marche on s'en fiche

/*function [ invGD, hD ]  = restore_i_influence(yi, wi,hD,invGD,l_Actif,gammaY)
    hD=hD+gammaY*yi*wi';
    for l=l_Actif
        invgD=invGD{l}; % m KxK
        invGD(l)={invgD - invgD*(wi*wi')*invgD/(1/gammaY+wi'*invgD*wi)};
    end

end
*/
 void restore_i_influence(gsl_matrix** tab_invGD, gsl_matrix* hD, 
 						gsl_vector* yi, gsl_vector* wi, gsl_vector* l_Actif,double gammaY)
{   


 
    int l;

    /*
    printf("\n Début restore \n");
    printf(" hD: size 1 =%zu , et size2 %zu\n",hD->size1,hD->size2);
    printf("size yi=%zu\n, size wi=%zu\n", yi->size,  wi->size );*/
		////A = \alpha x y^T + A of the matrix A/////
	////gsl_blas_dger (alpha, x, y, A)/////

    /*printf("\n Avant tMp \n");
     for (size_t la = 0; la < l_Actif->size; la++) {
        l= (int) gsl_vector_get(l_Actif, la);
        printf("tab_invGD[%d] size 1=%zu, size2=%zu, tda=%zu , adresse=%p \n", l, tab_invGD[l]->size1, tab_invGD[l]->size2, tab_invGD[l]->tda,tab_invGD[l]);
     }*/

    //gsl_matrix *tMp = gsl_matrix_alloc(P, K); 
    //gsl_blas_dger (gammaY, yi, wi, tMp); //gammaY*yi*wi'
    //gsl_matrix_add (hD, tMp);
    //gsl_matrix_free(tMp);

    
	gsl_blas_dger (gammaY, yi, wi, hD); /// Parameter 10 to routine ./source_ger.h was incorrect
//        hD=hD+gammaY*yi*wi'; %m : PxK attention yi.*yflag_i=yi
 //   printf("passe hD=hD+gammaY*yi*wi'\n");

    /* printf("\n Apres tMp \n");
     for (size_t la = 0; la < l_Actif->size; la++) {
        l= (int) gsl_vector_get (l_Actif, la);
        printf("tab_invGD[%d] size 1=%zu, size2=%zu, tda=%zu , adresse=%p \n", l, tab_invGD[l]->size1, tab_invGD[l]->size2, tab_invGD[l]->tda,tab_invGD[l]);
    }*/

    size_t K = hD->size2;
	gsl_matrix* wiwiT = gsl_matrix_alloc(K,K);
  
	gsl_blas_dger (1.0, wi, wi, wiwiT); //wi*wi' : matrix

	double wiT_invgD_wi=0.0;
	gsl_vector* invgDwi= gsl_vector_alloc (K);
    //gsl_vector_add_constant (invgDwi, 1.0);//DEBUGG

	gsl_matrix* invgDwiwiT=gsl_matrix_alloc(K,K) ;
	gsl_matrix* invgd_Div_wiT_invgD_wi= gsl_matrix_alloc(K,K);
	
    //printf("fin init\n");
    //printf("Size actif %zu\n", l_Actif->size );


   

	for (size_t la = 0; la < l_Actif->size; la++) {
        //printf("restore i %zu \n", la);
		l = (int) gsl_vector_get (l_Actif, la);

		//invgD=invGD{l}; on fait pas en C

		//Begin : invgD=invgD - invgD*(wi*wi')*invgD/(1/gammaY+wi'*invgD*wi);
		//invgDwi = gsl_vector_calloc (K);
        // int gsl_blas_dgemv (CBLAS_TRANSPOSE_t TransA, double alpha, const gsl_matrix * A, const gsl_vector * x, double beta, gsl_vector * y)
        // y = \alpha op(A) x + \beta y,
          
        /*printf("invgDwi = %zu \n",invgDwi->size);
        for (size_t size=0;size<invgDwi->size;size++){
                printf(" %f ", gsl_vector_get(invgDwi,size));
            }
            printf("\n");*/


        /*printf("wi = \n");
         for (size_t size=0;size<wi->size;size++){
                printf(" %f ", gsl_vector_get(wi,size));
            }
            printf("\n");*/

        //printf("tab_invGD[%d] size 1=%zu, size2=%zu \n", l, tab_invGD[l]->size1, tab_invGD[l]->size2);

		gsl_blas_dgemv (CblasNoTrans, 1.0, tab_invGD[l], wi, 0.0, invgDwi); //wi_invG=invgD*wi (vector)
		// Parameter 7 to routine ./source_gemv_r.h was incorrect -> pb tda

        //printf("passe gsl_blas_dgemv restore\n");

		gsl_blas_ddot (invgDwi, wi, &wiT_invgD_wi); // s: wi'*invgD*wi: wi' *scalaire invgDwi et mettre le résultat dans wiT_invgD_wi
		


        wiT_invgD_wi += 1/gammaY; //wi'*invgD*wi+1/gammaY; sclaire

	
		//invgd_Div_wiT_invgD_wi = gsl_matrix_calloc(K,K);
		gsl_matrix_memcpy (invgd_Div_wiT_invgD_wi, tab_invGD[l]); //copy invgD dans invgd_Div_wiT_invgD_wi
		gsl_matrix_scale (invgd_Div_wiT_invgD_wi, 1.0/wiT_invgD_wi); //invgD/(wi'*invgD*wi+1/gammaY)
		
		//invgDwiwiT =  gsl_matrix_calloc(K,K);
		gsl_blas_dgemm (CblasNoTrans, CblasNoTrans, 1.0, tab_invGD[l], wiwiT, 0.0, invgDwiwiT); //invgD*(wi*wi')

		//////C = \alpha op(A) op(B) + \beta C///////
		//////gsl_blas_dgemm ( TransA,TransB,  alpha,  A, B, beta, gC) ////////
		gsl_blas_dgemm (CblasNoTrans, CblasNoTrans, -1.0, invgDwiwiT , invgd_Div_wiT_invgD_wi , 1.0, tab_invGD[l]); 


		//invgD= - invgD*(wi*wi') * invgD/(wi'*invgD*wi+1/gammaY) + invgD ;
		//invGD(l)={invgD}; % covariance of D 
		
		//Fin: invgD=invgD - invgD*(wi*wi')*invgD/(1/gammaY+wi'*invgD*wi);
		
        /*if (tab_invGD[l]->size1 != tab_invGD[l]->size2){
                printf(" faux 3\n");
        }*/

        //gsl_vector_free(invgDwi);
	}
	gsl_matrix_free(wiwiT);
	gsl_vector_free(invgDwi);
	gsl_matrix_free(invgDwiwiT);
	gsl_matrix_free(invgd_Div_wiT_invgD_wi);

}


void compute_for_MH(double* lZinit, double* lZprop,
                    size_t K, size_t nb_singleton, size_t nb_prop, double sigmaS, double varY,
                    gsl_matrix** tab_invGD, gsl_matrix* muD,
                    gsl_vector* l_Actif_of_i, gsl_vector* yi_Actif, gsl_vector* wi,gsl_vector* wi_propo,gsl_vector* s_propo)
{   

    double tmp;
    double myG_init, myG_prop, syG_init, syG_prop;
    size_t l,la;
    gsl_vector_view view_vectTmp_K;
    gsl_vector * invgDwi=gsl_vector_alloc(K); 

    if (nb_prop>0) {
    gsl_blas_ddot(s_propo, s_propo,  &tmp); 
    //tmp = tmp*varD +varY; // tmp=snew_propo'*snew_propo*varD + varY;
    tmp = tmp/(double)P +varY; // tmp=snew_propo'*snew_propo*varD + varY;
    }
    else{
    tmp=varY;
    }


    if (nb_singleton==K){ //isempty(atomesUsed) : tout est singletons
        for (la=0; la<l_Actif_of_i->size; la++){ 
            
            l=(size_t) gsl_vector_get(l_Actif_of_i,la);
            
            view_vectTmp_K=gsl_matrix_row(muD, l); //muD(l,:)
            myG_init=0.0;
            syG_init=0.0;
            gsl_blas_ddot (&view_vectTmp_K.vector, wi,  &myG_init); // myG_init=muD(l_Actif_of_i,:) * wG; 

            //invgD=invGD{l};
            //syG_init(o)=wG'*invgD*wG+varY;
            
            gsl_blas_dgemv (CblasNoTrans, 1.0, tab_invGD[l], wi, 0.0, invgDwi); //wi_invG=invgD*wi (vector)
            gsl_blas_ddot(invgDwi, wi, &syG_init);
            syG_init+=varY;

            *lZinit += ((log(syG_init) + pow(gsl_vector_get(yi_Actif,la ) - myG_init,2) / syG_init)) ;
            //-0.5*sum( log( syG_init ) +((y_pAlume-myG_init).^2)./syG_init ) ;

            myG_prop=0.0;
            syG_prop=0.0;
            gsl_blas_ddot (&view_vectTmp_K.vector, wi,  &myG_prop); // myG_prop=muD(l_Actif_of_i,:) * wi_propo;
            //invgD=invGD{l}; syG_init(o)=wi_propo'*invgD*wi_propo + snew_propo'*snew_propo*varD + varY;
            gsl_blas_dgemv (CblasNoTrans, 1.0, tab_invGD[l], wi_propo, 0.0, invgDwi); //wi_invG=invgD*wi (vector)
            gsl_blas_ddot(invgDwi, wi_propo, &syG_prop);
            syG_prop+=tmp;
            *lZprop += ((log(syG_prop) + pow(gsl_vector_get(yi_Actif,la ) - myG_prop,2) / syG_prop));  

        }
        *lZinit=(*lZinit) * (-0.5);
        *lZprop=(*lZprop) * (-0.5);

    }
    else{ //lZinit déja calculer dehors
        for (la=0; la<l_Actif_of_i->size; la++){
            
            l=(size_t) gsl_vector_get(l_Actif_of_i,la);

            view_vectTmp_K=gsl_matrix_row(muD, l); //muD(l,:)
            myG_prop=0.0;
            gsl_blas_ddot (&view_vectTmp_K.vector, wi_propo,  &myG_prop); // myG_init=muD(l_Actif_of_i,:) * wi; 
            
            //invgD=invGD{l}; syG_init(o)=wi_propo'*invgD*wi_propo + snew_propo'*snew_propo*varD + varY;
            
            gsl_blas_dgemv(CblasNoTrans, 1.0, tab_invGD[l], wi_propo, 0, invgDwi); //wi_invG=invgD*wi (vector)
            syG_prop=0.0;
            gsl_blas_ddot(invgDwi, wi_propo, &syG_prop);
            syG_prop+=tmp;
            *lZprop += (log(syG_prop) + pow(gsl_vector_get(yi_Actif,la) - myG_prop,2) / syG_prop);  

        }
        *lZprop=(*lZprop) * (-0.5);
    }
    gsl_vector_free(invgDwi);
}



void inferZki (double *wki, double *lZinit,
			   gsl_rng *r, double mk_i, size_t k, gsl_vector *wG, double sigmaS,  double varY,
               gsl_matrix **tab_invGD, gsl_matrix *muD, gsl_vector *l_Actif_of_i, gsl_vector *yi_Actif) 
{
    

    double lZ0=0.0;
    double lZ1=0.0;   
    double myG_0=0.0;
    double myG_1=0.0;
    double syG_0=0.0;
    double syG_1=0.0;
    size_t l;
    gsl_vector * invgDwi=gsl_vector_alloc(wG->size); 
    gsl_vector *wG1 = gsl_vector_alloc(wG->size);
    gsl_vector_view view_vectTmp_K;



    //gsl_rng_env_setup();
    //gsl_rng *r = gsl_rng_alloc( gsl_rng_mt19937);


    //lprior1 = log(m_i(k)); %s
    double lprior1 = log( mk_i );

    //lprior0 = log(N-m_i(k)); %s
    double lprior0 = log( (double)N - mk_i );

    //if wG(k)==0
    //    wG( k )=randn*sigmaS; %s
    //end   
    if( gsl_vector_get( wG, k ) == 0.0 ) {
        gsl_vector_set( wG, k, gsl_ran_gaussian(r, sigmaS) );
    }

    //wG1=wG; % v: Kx1;
    gsl_vector_memcpy(wG1, wG); //wG1 quand zki=1
    gsl_vector_set( wG, k, 0.0 );//wG quand zki=0;

    for (size_t la=0; la<l_Actif_of_i->size; la++){ 

            l= (size_t) gsl_vector_get(l_Actif_of_i,la);
            
            view_vectTmp_K=gsl_matrix_row(muD, l); //muD(l,:) // sizeK

            ////////////////// cas zki=0
            gsl_blas_ddot (&view_vectTmp_K.vector, wG,  &myG_0); // myG_init=muD(l_Actif_of_i,:) * wG; 

            //invgD=invGD{l};syG_init(o)=wG'*invgD*wG+varY;  
            gsl_blas_dgemv (CblasNoTrans, 1.0, tab_invGD[l], wG, 0, invgDwi); //wi_invG=invgD*wi (vector)
            gsl_blas_ddot(invgDwi, wG, &syG_0);
            syG_0+=varY;

            lZ0 += (log(syG_0) + pow(gsl_vector_get(yi_Actif,la ) - myG_0,2) / syG_0) ;
            //-0.5*sum( log( syG_init ) +((y_pAlume-myG_init).^2)./syG_init ) ;

            ////////////////// cas zki=1
            gsl_blas_ddot (&view_vectTmp_K.vector, wG1,  &myG_1); // myG_prop=muD(l_Actif_of_i,:) * wG1;
            //invgD=invGD{l}; syG_init(o)=wG1'*invgD*wiG1 + varY;
            gsl_blas_dgemv (CblasNoTrans, 1.0, tab_invGD[l], wG1, 0, invgDwi); //wi_invG=invgD*wi (vector)
            gsl_blas_ddot(invgDwi, wG1, &syG_1);
            syG_1+=varY;
            lZ1 += (log(syG_1) + pow(gsl_vector_get(yi_Actif,la ) - myG_1,2) / syG_1);  
    }
    lZ0=lZ0*(-0.5);
    lZ1=lZ1*(-0.5);
    gsl_vector_free(invgDwi);

    if( (rand()/(double) RAND_MAX) < 1/ (1 + exp(  (lprior0+lZ0)  -  (lprior1+lZ1)  )) ){
    	*wki=gsl_vector_get(wG1,k);
    	*lZinit=lZ1;

    }
    else{
    	*wki=0.0;
    	*lZinit=lZ0;
    }

	gsl_vector_free(wG1);
	//gsl_rng_free(r);

}


double sumAllMatrixCoef(gsl_matrix* M, double sigmaS) {        
    size_t L = M->size1;
    size_t C = M->size2;
    double sum=0.0;
    size_t l,c;
	double sigmaS_sq = (sigmaS*sigmaS);
    for (c = 0; c < C; c++) {
        for (l = 0; l < L; l++) {
        	if (gsl_matrix_get(M, l, c) == 0.0){
            	sum += sigmaS_sq;
        	}else{
        		sum += ( pow(gsl_matrix_get(M, l, c),2) );
        	}
        }
    }
 
    return sum;                                                                   
} 


double SampleGammaS(gsl_rng *r, gsl_matrix* W, double sigmaS, int option){
	double gammaS=0.0;;
	//gsl_rng *r = gsl_rng_alloc(gsl_rng_mt19937);
	size_t KN=W->size1*W->size2;//KN=numel(W);

	//When Zik=0, we consider that Sik=sigmaS (in the precedent iteration)

	double SUM_W= sumAllMatrixCoef(W,sigmaS);  //SUM_W=sum(sum(W.^2)) + (KN-nnz(W))*(sigmaS^2);

    //double ei, fi;
	switch(option){
		case 1: //if option==1 %Jeffreys prior
			gammaS =gsl_ran_gamma(r,KN/2,2/SUM_W);//gammaS=gamrnd(KN/2+2,2/SUM_W,1);
			break;

		case 2: //%Maximum-a-Posteriori with a prior non-informative
        {
    		double ei = 0.000001 + 0.5*KN;
    		double fi = 0.000001 + 0.5*SUM_W;
    		gammaS =gsl_ran_gamma(r,ei,1.0/fi);
			break;
        }

		default:
			printf("Warning option !!!!! 1 for Jeffreys or 2 for MAP \n");
        	break;
	}
	//gsl_rng_free(r);
	return gammaS;

}

double SampleGammaY(gsl_rng *r, gsl_matrix* E_Y, int option){

	double gammaY=0.0;
	//gsl_rng *r = gsl_rng_alloc(gsl_rng_mt19937);
	int sumYflag=nnz_Matrix(Yflag);
 
	switch(option){
		case 1: //if option==1 %Jeffreys prior
			gammaY =gsl_ran_gamma(r, (double) sumYflag/2.0, 2.0/matrix_square_trace(E_Y) );// gammaY = gamrnd(sumYflag/2+2,2/trace(E_Y*E_Y'),1);
			break;

		case 2: //%Maximum-a-Posteriori with a prior non-informative
        {
    		double ci = 0.000001 + 0.5*(double)sumYflag; //ci = c0 + 0.5*sumYflag;
    		double di = 0.000001 + 0.5*matrix_square_trace(E_Y); //di = d0 + 0.5*sum(sum((E_Y).^2));
    		gammaY =gsl_ran_gamma(r,ci,1.0/di);     //    gammaY=gamrnd(ci,1./di);
			break;
        }
		default:
			printf("Warning option !!!!! 1 for Jeffreys or 2 for MAP \n");
        	break;
	}

//gsl_rng_free(r);
return gammaY;
}

void Extrait_User_Of_k(gsl_matrix* Xk_sub, gsl_matrix* Yf_sub, gsl_vector* wk_sub,
					   gsl_matrix* X_k, gsl_vector *wk, gsl_vector* index)
{
	gsl_vector_view view_vect_P1;
	gsl_vector_view view_vect_P2;
	for(size_t i=0; i<index->size; i++){
    	view_vect_P1=gsl_matrix_column(X_k,  (size_t) gsl_vector_get(index,i));
        gsl_matrix_set_col(Xk_sub, i, &view_vect_P1.vector);
        view_vect_P2=gsl_matrix_column(Yflag,  (size_t) gsl_vector_get(index,i));
        gsl_matrix_set_col(Yf_sub, i, &view_vect_P2.vector);
        gsl_vector_set(wk_sub,i, gsl_vector_get(wk, (size_t) gsl_vector_get(index,i) ) );
    }

	
}


void Copy_SubMatrix(gsl_matrix* Xk, 
					gsl_matrix* Xk_sub , gsl_vector* index)
{
	//gsl_vector* vect_P=gsl_vector_alloc(P);
    gsl_vector_view  view_vect_P;
	for(size_t i=0; i<index->size; i++){
        //gsl_matrix_get_col (vect_P, Xk_sub, i);
    	view_vect_P=gsl_matrix_column(Xk_sub,  i);
        //gsl_matrix_set_col(Xk, (size_t) gsl_vector_get(index,i), vect_P);
        gsl_matrix_set_col(Xk, (size_t) gsl_vector_get(index,i), &view_vect_P.vector);
    }
    //gsl_vector_free(vect_P);
	
}



gsl_vector *SampleDk(gsl_rng *r, gsl_matrix* Yf_sub, gsl_matrix* X_k_sub, gsl_vector* wk_sub ,double gammaY){
	

	gsl_vector* mu_Dk=gsl_vector_alloc(P);
	gsl_vector* sig_Dk=gsl_vector_alloc(P);

	//sig_Dk = 1./(gammaY*Yflag(:,zk)*(wk'.^2)+P); % v : P x1
	gsl_vector* wk_subsquare=gsl_vector_alloc(wk_sub->size);
	gsl_vector_memcpy(wk_subsquare,wk_sub); 
	gsl_vector_mul (wk_subsquare, wk_sub);
	gsl_blas_dgemv (CblasNoTrans, gammaY, Yf_sub, wk_subsquare, 0.0, mu_Dk); //sig_Dk=gammaY*Yflag(:,zk)*(wk'.^2)
    //CMT: c'est bien mu_Dk ici car à la fin on fera
    //gsl_vector_div (sig_Dk, mu_Dk);
    // ça veut dire sig_Dk./mu_Dk et enregistrer dans sig_Dk. 
    // C'est juste un technique pour éviter de créer un autre vecteur.
    gsl_vector_add_constant (mu_Dk, (double) P); // sig_Dk=sig_Dk+P
    gsl_vector_add_constant (sig_Dk, 1.0); // vector que des 1
    gsl_vector_div (sig_Dk, mu_Dk); //// sig_Dk=s1./sig_Dk


	//mu_D = gammaY*sig_Dk.*(X_k(:,zk)*wk'); % v : P x1
    //gsl_vector_set_zero (mu_Dk);
	gsl_blas_dgemv (CblasNoTrans, gammaY, X_k_sub, wk_sub, 0.0, mu_Dk); //mu_Dk=gammaY*(X_k(:,zk)*wk')(vector)
    gsl_vector_mul (mu_Dk, sig_Dk);  //mu_Dk=sig_Dk.*mu_Dk



	gsl_vector* dk=randn_vect(r,1.0,P) ; //dk = mu_Dk + randn(P,1).*sqrt(sig_Dk); % v : P x 1

	for(size_t i=0; i<P; i++){
		 gsl_vector_set (sig_Dk, i,  sqrt( gsl_vector_get(sig_Dk,i) ) );
	}// faire la racine carrée de sigma_Dk
 	gsl_vector_mul (dk, sig_Dk); // sigma_Dk est déja fait racine carrée
 	gsl_vector_add (dk, mu_Dk); 

 	gsl_vector_free(wk_subsquare);
	gsl_vector_free(mu_Dk);
	gsl_vector_free(sig_Dk);
	return dk;
}

gsl_vector *SampleSk(gsl_rng *r, gsl_matrix* Yf_sub, gsl_matrix* X_k_sub, size_t nk, gsl_vector* dk ,double gammaY,double gammaS){
	

	gsl_vector* mu_Sk=gsl_vector_alloc(nk);
	gsl_vector* sig_Sk=gsl_vector_alloc(nk);

    //sigS1 = 1./(gammaS + gammaY*(D(:,k).^2)'*Yflag(:,zk));
	gsl_vector* dk_square=gsl_vector_alloc(P);
	gsl_vector_memcpy(dk_square,dk); 
	gsl_vector_mul (dk_square, dk);
	gsl_blas_dgemv (CblasTrans, gammaY, Yf_sub, dk_square, 0.0, mu_Sk); //sig_Sk=gammaY*(D(:,k).^2)'*Yflag(:,zk))
    //CMT: c'est bien mu_SK ici car à la fin on fera
    //gsl_vector_div (sig_Sk, mu_Sk);
    // ça veut dire sig_Sk./mu_Sk et enregistrer dans sig_Sk. 
    // C'est juste un technique pour éviter de créer un autre vecteur.
    gsl_vector_add_constant (mu_Sk, gammaS); // sig_Dk=sig_Dk+gammaS
    gsl_vector_add_constant (sig_Sk, 1.0); // vector que des 1
    gsl_vector_div (sig_Sk, mu_Sk); //// sig_Dk=s1./sig_Dk



	//mu_Sk=sigS1.*(gammaY*( D(:,k)'*X_k(:,zk) );
    //gsl_vector_set_zero (mu_Sk);
	gsl_blas_dgemv (CblasTrans, gammaY, X_k_sub, dk, 0.0, mu_Sk); //mu_Sk=(gammaY*( D(:,k)'*X_k(:,zk) );
    gsl_vector_mul (mu_Sk, sig_Sk);  //mu_Dk=sig_Dk.*mu_Dk



	gsl_vector* sk=randn_vect(r, 1.0,nk) ; // les sk où zk=1
    //sk = mu_Sk + randn(nk,1).*sqrt(sig_Sk); % v : nk x 1

	for(size_t i=0; i<nk; i++){
		 gsl_vector_set (sig_Sk, i,  sqrt( gsl_vector_get(sig_Sk,i) ) );
	}// faire la racine carrée de sigma_Sk
 	gsl_vector_mul (sk, sig_Sk); // sigma_Sk est déja fait racine carrée
 	gsl_vector_add (sk, mu_Sk); 

 	gsl_vector_free(dk_square);
	gsl_vector_free(mu_Sk);
	gsl_vector_free(sig_Sk);
	return sk;
}

void Copy_2SubMatrix(gsl_matrix* Xk, gsl_matrix* W,
					gsl_matrix* Xk_sub , gsl_vector* wk_sub, gsl_vector* index, size_t k)
{
	gsl_vector_view view_vect_P;
	size_t true_i;
	for(size_t i=0; i<index->size; i++){
		true_i=(size_t) gsl_vector_get(index,i);
    	view_vect_P=gsl_matrix_column(Xk_sub,  i);
        gsl_matrix_set_col(Xk, true_i, &view_vect_P.vector);
        gsl_matrix_set(W,k,true_i, gsl_vector_get(wk_sub,i));
    }

	
}

