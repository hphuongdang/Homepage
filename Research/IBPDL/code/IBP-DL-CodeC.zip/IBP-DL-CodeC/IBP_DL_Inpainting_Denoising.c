#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_rng.h>                                                      
#include <gsl/gsl_randist.h>    
#include <gsl/gsl_blas.h>  
#include "utils.h"
#include "functions.h"
#include "IBP_DL_Inpainting_Denoising.h"

extern gsl_matrix* Y ; 
extern gsl_matrix* Yflag ; 
extern size_t N;
extern size_t P;




void IBP_DL_Inpainting_Denoising(gsl_matrix** tab_D, gsl_matrix** Coef, double* Alpha, double* SigmaNoise, double* SigmaCoef, int *iter,
		int MaxIter, double sigmaY, int UpdateOption, t_args args)
{

	//Input : int MaxIter, double sigmaY
	//Output: 

	//double *log_LH = (double *)malloc(MaxIter* sizeof(double) );
	/* Les grains de l''aléatoire /////////
	   gsl_rng * r;
	   const gsl_rng_type * T;
	   gsl_rng_env_setup();
	   T = gsl_rng_default;
	   r = gsl_rng_alloc (T); */

	gsl_rng_env_setup();
	gsl_rng *r = gsl_rng_alloc(gsl_rng_mt19937);

	// Les initialisations
	double H_N =sum1divifrom1toN(N); 
  //printf("H_N=%f \n", H_N); ok, c bon
 


	gsl_vector *nb_pixelActif= sumMatrix(Yflag, 1);// free à la fin de la fonction 
	double varY=sigmaY*sigmaY;
	double gammaY=1.0/varY;

	double varD=1.0/(double)P;

	double sigmaS=1.0;
	double gammaS=1.0;



	double alpha=10; 
	double param= alpha / (double)N;
	size_t K=1; // ----revoir ici pour voir si c'est 1 ou 0


	// Les variables utilisent pour la fonction 
	size_t i,sample, k, l;
	size_t nb_singleton, nb_prop;

	size_t *index_singletons = NULL;
	*iter=0;
	int mk_i;
	int cvg=0;
	int supprime=0;
	int acceptation;

	double wki,lZinit,lZprop;
	size_t Perm[N];
	for (i = 0; i < N; i++)
	{
		Perm[i] = i;
	}
	gsl_vector_view viewsizeN;
	gsl_vector_view viewsizeP;
	

	gsl_vector_view view_yflag_i ; 
	gsl_vector_view view_yi ; 
	gsl_vector_view view_wi ;
	gsl_vector_view view_hl ;

	gsl_vector* hDlinvgDl;
	gsl_vector* yi_Actif;
	gsl_vector* l_Actif_of_i;
	gsl_matrix* muD ;
	gsl_vector* wi_propo;

	gsl_matrix* M_k_i=gsl_matrix_calloc(1,N);
	
	gsl_vector_view m_k_view;

	//gsl_vector* m_i ;
	
	//gsl_matrix_view M_k_i_add_view;
	gsl_matrix** tab_invGD ;
	gsl_matrix*  hD;  //hD et D ont même taille du coup, on va pas créer un nouveau D.
  	gsl_matrix* W=gsl_matrix_calloc(K,N); 

	gsl_vector_view yfl;
	gsl_vector **indexs_actif = malloc( P * sizeof(gsl_vector *));
	for (i = 0; i < P; i++) {
		yfl = gsl_matrix_row(Yflag, i); //Yflag(l,:) size N
		indexs_actif[i] = vector_find( &yfl.vector , E_EQ, 1.0 ) ;
	}
  //gsl_matrix* W_pointer;

	while ( *iter<MaxIter && cvg < 10 ){
		//gsl_matrix* W=gsl_matrix_calloc(K,N); //initialise 1 ligne de 0 mais K en vrai =0
		//r = gsl_rng_alloc(gsl_rng_mt19937);
		// in the loop is more otimal in C : K_new=poissrnd(alpha/N,1,N);  % v taille 1xN

		//printf("\nIteration: %d\n", *iter);
		acceptation=0; //réinit à chq lopp while


    //if( *iter > 0) {
    //  W_pointer = gsl_matrix_alloc(K,N);
    //  gsl_matrix_memcpy(W_pointer, W);
    //  W = W_pointer;
   // }

		
		tab_invGD = malloc( P * sizeof( gsl_matrix *)); // chq element de tab_invGD est une matrice KxK, 
		for (l=0; l<P; l++){
			tab_invGD[l]=gsl_matrix_calloc(K,K);
		}

		// on free tab_invGD avant echan.D,S -> alloc ici car K change.	
    	hD=gsl_matrix_calloc(P, K);	
		//gsl_matrix_scale (hD, 0.0);
		//on free hD et (re)allooc au recalculate occasionally, ds information_form on a déja gsl_matrix_free(tab_invGD[l]);  .
		//on free ensuite à la fin.
    /*if(gsl_matrix_isnull(W)){
      printf("iteration %d début W est null\n", *iter);
    }*/
		information_form( tab_invGD, hD ,W,  gammaY, indexs_actif); //retourne tab_invGD et hD
		//printf("Je passe information_form\n");
    /*for (l=0;l<P;l++){
    printf("\n hD(%zu,:) =  ",l);
      for (k=0;k<K;k++){
            printf("%f ", gsl_matrix_get(hD,l,k) );
      }
      printf("\n");
      getchar();
    }*/

    		gsl_ran_shuffle (r, Perm, N, sizeof (size_t)); //perm = randperm( N ); //Mixe order of the data

		for (sample=0; sample<N; sample++){
			
			
			i=Perm[sample];
			if(gsl_vector_get(nb_pixelActif,i)<1.0){
				continue;
			}
      
			view_yflag_i = gsl_matrix_column (Yflag, i); //view //view_yflag_i=Yflag( : , i );
			view_yi = gsl_matrix_column (Y, i); //view //view_yi=Y( : , i );
			view_wi = gsl_matrix_column (W, i); //view //view_wi=W(:,i);

			//printf("\n alloc yi_Actif" );
			yi_Actif= gsl_vector_alloc( (size_t) gsl_vector_get(nb_pixelActif,i)); // On free les 2 à la fin 

			//printf("\n alloc l_Actif_of_i" );
			l_Actif_of_i= gsl_vector_alloc(( size_t)  gsl_vector_get(nb_pixelActif,i));// chaque boucle for i.

			//printf("\n alloc muD" );
			muD = gsl_matrix_alloc(P,W->size1);// on free à la fin Add new atoms

			//printf("\n Begin remove\n" );
			remove_i_influence(tab_invGD, hD, muD, l_Actif_of_i, yi_Actif, //remove: sortie tab_invGD, hD, muD, l_Actif_of_i, yi_Actif.
					&view_yflag_i.vector ,&view_yi.vector, &view_wi.vector, gammaY);
			//printf("\n Sample: %zu\n passe remove " , sample);
        /*  for (l=0;l<P;l++){
            printf("\n hD(%zu,:) =  ",l);
            for (k=0;k<K;k++){
              printf("%f ", gsl_matrix_get(hD,l,k) );
            }
            printf("\n");
          }*/
			wi_propo = gsl_vector_alloc(view_wi.vector.size); // préparer pour mettre en 0 les signeltons et free après 
			//size_t *index_singletons = malloc(K * sizeof(size_t) ); // on free les deux à la fin add new atoms
			

			/********** BEGIN infer zki **************/
      		nb_singleton=0; //réinit à chq lopp i
			  //free après for k 
			lZinit=0.0;
			//printf("\n passe sumLogicalMatrixExceptOne" );
			
			//mk_i_propo = gsl_vector_alloc(view_wi.vector.size);
			index_singletons = (size_t *)malloc(K* sizeof(size_t) );
			


			for(k=0; k<K; k++){
				m_k_view=gsl_matrix_row(M_k_i,k);
				mk_i= (int) gsl_vector_get(&m_k_view.vector,i);
				if( mk_i>0 ){
					double tmp=gsl_vector_get(&view_wi.vector,k);
					//printf("\n k: %zu\n", k);
					inferZki (&wki, &lZinit, //sortie les 2 double wki et lZinit : du coup &
							r, mk_i,k, &view_wi.vector, sigmaS, varY, tab_invGD, muD, l_Actif_of_i, yi_Actif);
            /*if(wki!=0){
              printf("w%zu%zu=%f \n",k,i,wki );

            }*/		
            		gsl_vector_set(&view_wi.vector, k, wki);// changer aussi W
					gsl_vector_set(wi_propo, k, wki);
					
					

              		if(tmp==0.0 && wki!= 0.0){
              		 
              			gsl_vector_add_constant(&m_k_view.vector, 1);
              			gsl_vector_set(&m_k_view.vector,i,gsl_vector_get(&m_k_view.vector,i)-1);
          				
          			}
          			else if(tmp!=0.0 && wki==0.0){
						gsl_vector_add_constant(&m_k_view.vector, -1);
						gsl_vector_set(&m_k_view.vector,i,gsl_vector_get(&m_k_view.vector,i)+1);
						
          			}
          			

				}
				else if(gsl_vector_get(&view_wi.vector,k)!=0.0){
					index_singletons[nb_singleton++]= k;
					//nb_singleton++;
					gsl_vector_set(wi_propo, k, 0.0); //remove (set to 0) the singletons wi_propo( index_singletons ) = 0
					
					
				}
			} //end for k
			
			//printf("\n passe boucle k" );
			
			//gsl_matrix_set_col (W, i, wi); on a déja faire quand on fait gsl_vector_set(&view_wi.vector, k, wki);
			/********** FIN infer zki **************/

			/********** BEGIN Add new atoms **************/
			nb_prop=  gsl_ran_poisson(r,param);
			// wi_propo =wG; wi_propo( index_singletons ) = 0; %%remove (set to 0) the singletons :faire déja En haut
			lZprop=0.0;
			gsl_vector* s_propo;
			if (nb_prop>0){
				s_propo = randn_vect(r, sigmaS, nb_prop);// s_propo=randn(nb_prop,1)*sigmaS; free à la fin add
			}
			else
			{
				s_propo = NULL;
			}	
			//printf("\n passe poissrnd k" );



			if (nb_prop >0  || nb_singleton >0){
        //printf("var Y= %0.15lf \n",varY);
				compute_for_MH(&lZinit, &lZprop,
						K, nb_singleton, nb_prop, sigmaS, varY,
						tab_invGD, muD,
						l_Actif_of_i, yi_Actif, &view_wi.vector, wi_propo,s_propo);
				//printf("\n passe MH" );

				// le changement de taille des matrices 
        //double seuil =log(rand()/(double) RAND_MAX);

        //if (nb_prop>0){
        //printf(" proposition= %zu , lZprop-lZinit=%f ,seuil = %f\n", nb_prop, lZprop-lZinit,seuil);
        //}
				if (lZprop-lZinit > log(rand()/(double) RAND_MAX)){ //rand()/(double) RAND_MAX : loi uniforme entre 0 et 1.
					acceptation++;
					//W(1:end+k_new_propo,i)=[wi_propo, s_propo]; % le reste =0 , add row
					gsl_matrix_set_col(W, i, wi_propo);
					
					if(nb_prop>0){
						//printf("\n nb_prop=%zu >0", nb_prop);
						//W = matrix_add_rows( W , nb_prop);
						K=W->size1;
						//W->size1=K+nb_prop;
						//////// A voir pour cobiner 2 for/////////
						W = matrix_add_rows( W , nb_prop);
						M_k_i = matrix_add_rows( M_k_i , nb_prop);
						//M_k_i_add_view = gsl_matrix_submatrix (M_k_i, K, 0, nb_prop, N);
						//gsl_matrix_set_all(&M_k_i_add_view.matrix,1.0);
						for (k=0; k<nb_prop; k++){	

							gsl_matrix_set(W,K+k,i,gsl_vector_get(s_propo,k));

							m_k_view=gsl_matrix_row(M_k_i,K+k);
							gsl_vector_set_all(&m_k_view.vector,1.0);
							gsl_vector_set(&m_k_view.vector,i,0.0);
						}



						//hD=[hD zeros(P,k_new_propo)]; 
						//hD->size2=hD->size2+nb_prop;
						//hD->tda=hD->tda+nb_prop;
						hD=matrix_add_cols(hD,nb_prop);
						/*invgDnew1= zeros(Kold,k_new_propo);
						  invgDnew2 = [zeros(k_new_propo,Kold) eye(k_new_propo)*sigmaD^2];
						  for l=1:P
						  invGD(l) = {[invGD{l} invgDnew1; invgDnew2 ]};%eye(k_new)*(1/sum(yflagG))];%
						  end*/


						for (l=0; l<P;l++){
							//tab_invGD[l]->size1=tab_invGD[l]->size1+nb_prop;
							//tab_invGD[l]->size2=tab_invGD[l]->size2+nb_prop;
							//tab_invGD[l]->tda=tab_invGD[l]->tda+nb_prop;
							tab_invGD[l]=matrix_add_cols(tab_invGD[l],nb_prop);
							tab_invGD[l]=matrix_add_rows(tab_invGD[l],nb_prop);
							for (k=0; k<nb_prop; k++){
								gsl_matrix_set(tab_invGD[l],K+k,K+k,varD);
							}
						} 
						K=K+nb_prop; //Kutiliser ensuite pour les autres i
						//printf("\n passe changement W hD gD K=%zu\n", K );

					}
					if(nb_singleton>0){
							for(k=0;k<nb_singleton;k++){
								m_k_view=gsl_matrix_row(M_k_i,index_singletons[k]);
								gsl_vector_set_zero(&m_k_view.vector);
								
							}
							
					}

				}

			}
			else{
				acceptation++;
				//printf("\n pas MH");

			}
			free(index_singletons);
			gsl_vector_free(wi_propo);
			gsl_matrix_free(muD);
			gsl_vector_free(s_propo);

			/********** FIN Add new atoms **************/
      /*if (!gsl_matrix_equal (Yorig, Y)){

        printf("\n Changement après Add new atoms \n ");
      }*/
			//printf("\n Fin Add");
			/********** BEGIN restore i influence **************/
			if ( fmod(sample, 50*log((double) N) ) == 0 ){ //recalculate occasionally  to avoid the accumulation of errors
				//W(~sum(logical(W),2),:)=[]; 
				//printf("\n Begin recalculate \n");
				gsl_vector* m_i=sumLogicalMatrix_FindNNZ(W,2); // %v : Kx1

				/* if (m_i){
				   printf("size m_i: %zu \n", m_i->size);
				   for(size_t j=0; j<m_i->size; j++){
				   printf("%f ", gsl_vector_get(m_i, j) );
				   }
				   }else{
				   printf("pas de m_i\n");
				   }*/
				if (m_i && m_i->size<K ){ // si il existe des lignes non utilisé dans W 

					K=m_i->size;
					//printf(" K = %zu \n", K);
					gsl_matrix* Wtmp=gsl_matrix_alloc(K,N);
					gsl_matrix* M_k_i_tmp=gsl_matrix_alloc(K,N);
					for (k=0;k<K;k++){
						viewsizeN=gsl_matrix_row( W,(size_t) gsl_vector_get(m_i,k) );
						gsl_matrix_set_row(Wtmp,k, &viewsizeN.vector) ;
						m_k_view=gsl_matrix_row( M_k_i,(size_t) gsl_vector_get(m_i,k) );
						gsl_matrix_set_row(M_k_i_tmp,k, &m_k_view.vector) ;

					}
					gsl_matrix_free(W);
					W=gsl_matrix_alloc(K,N);
					gsl_matrix_memcpy (W, Wtmp);
					gsl_matrix_free(Wtmp);
					gsl_matrix_free(M_k_i);
					M_k_i=gsl_matrix_alloc(K,N);
					gsl_matrix_memcpy (M_k_i, M_k_i_tmp);
					gsl_matrix_free(M_k_i_tmp);
				}
				else if(!m_i){// tous les ligne ne sont pas utilisés

					gsl_matrix_free(W);
					gsl_matrix_free(M_k_i);
					K=1; // en vrai =0
					W=gsl_matrix_alloc(K,N);
					M_k_i=gsl_matrix_calloc(K,N);

					//printf(" \n K = retombe à %zu", K );
				}

				gsl_vector_free(m_i);
				gsl_matrix_free(hD);
				//printf("\nK=%zu ", W->size1);///// pk ici c'est pas 1
				//printf("\nP=%zu ", P);
				hD= gsl_matrix_alloc(P, K);
        		for (l=0;l<P;l++){
          			gsl_matrix_free(tab_invGD[l]);
          			tab_invGD[l]=gsl_matrix_alloc(K,K);
        		}

        /*if(gsl_matrix_isnull(W)){
        printf("iteration %d recalcul W est null\n", *iter);
        }*/
				information_form( tab_invGD, hD ,W,  gammaY, indexs_actif); //?????????? free mais pas besoin de redéclarer
				//printf("\n passe information_form \n" );
				supprime=1;
			}
			else{ //Ajouter influence de data i
				// printf("\n Sample: %zu begin restore \n" , sample);
				//hD et les matrices dans tab_invGD est déja modifié dans Add new atoms
				//W aussi est changé dans Add new atoms.

				view_wi = gsl_matrix_column (W, i);

				restore_i_influence(tab_invGD, hD, &view_yi.vector, &view_wi.vector, l_Actif_of_i, gammaY); //pb ici
				//printf("\n Sample: %zu passe restore \n" , sample);
				supprime=0;  
			}
			/*************  FIN  Restore i influence **************/
      /*if (!gsl_matrix_equal (Yorig, Y)){

        printf("\nChangement après Restore\n");
      }*/

			gsl_vector_free(yi_Actif);
			gsl_vector_free(l_Actif_of_i);
		}//end for i
		// printf("\n FIN boucle  sample \n");


		/*D=zeros(P,size(W,1));
		  for l=1:P
		  D(l,:)= hD(l,:) * invGD{l};
		  end*/
		//comment: D et hD est même taille* on modifie sur hD 
		K=W->size1; // rechecker le K
		hDlinvgDl=gsl_vector_calloc(K);

		for (l=0; l<P; l++){
			view_hl=gsl_matrix_row(hD,l);
			gsl_blas_dgemv (CblasTrans, 1.0, tab_invGD[l], &view_hl.vector, 0.0, hDlinvgDl) ;
			gsl_matrix_set_row(hD,l, hDlinvgDl );  
			gsl_matrix_free(tab_invGD[l]);
		}
    gsl_vector_free(hDlinvgDl) ;
		//printf("\n Passe mettre à jour muD\n");

    /*D(:,~sum(W,2))=[];
    W(~sum(W,2),:)=[];*/
		if(!supprime){
			gsl_vector* m_i=sumLogicalMatrix_FindNNZ(W,2); //index k of sum non nul chercher les index utilisé
      //if m_i->size==K (tous les sont utilisé) -> pas besoin de supprimer
			if (m_i && m_i->size<K ){ // si il existe des lignes non utilisé dans W && 
				K=m_i->size; // nouveaux size K utilisé
				gsl_matrix* Dtmp=gsl_matrix_alloc(P,K);
				gsl_matrix* Wtmp=gsl_matrix_alloc(K,N);
				gsl_matrix* M_k_i_tmp=gsl_matrix_alloc(K,N);

				for (k=0;k<K;k++){
					m_k_view=gsl_matrix_row( M_k_i,(size_t) gsl_vector_get(m_i,k) );
					viewsizeN = gsl_matrix_row(W, (size_t) gsl_vector_get(m_i,k));
					viewsizeP = gsl_matrix_column(hD, (size_t) gsl_vector_get(m_i,k));
					gsl_matrix_set_row(M_k_i_tmp,k, &m_k_view.vector) ;
					gsl_matrix_set_row( Wtmp,k,&viewsizeN.vector ) ;
					gsl_matrix_set_col( Dtmp,k,&viewsizeP.vector ) ;
					
					
				}   

				gsl_matrix_free(hD);
				gsl_matrix_free(W);
				gsl_matrix_free(M_k_i);

				W=gsl_matrix_alloc(K,N);
				hD=gsl_matrix_alloc(P,K);
				M_k_i=gsl_matrix_alloc(K,N);

				gsl_matrix_memcpy (hD, Dtmp);
				gsl_matrix_memcpy (W, Wtmp);
				gsl_matrix_memcpy (M_k_i, M_k_i_tmp);

				gsl_matrix_free(Dtmp);
				gsl_matrix_free(Wtmp);
				gsl_matrix_free(M_k_i_tmp);

					
					
					
			}
			else if(!m_i){// tous les ligne ne sont pas utilisés
				gsl_matrix_free(hD);
				gsl_matrix_free(W);
				gsl_matrix_free(M_k_i);
				K=1; // en vrai =0
				W=gsl_matrix_alloc(K,N);
				hD=gsl_matrix_alloc(P,K);
				M_k_i=gsl_matrix_alloc(K,N);
			}
			gsl_vector_free(m_i);
		}

		
		/*comment: à partir de maintenant hD est D, on calloc ensuite au début de while pour éviter des erreurs->hD est hD */

      /*if (!gsl_matrix_equal (Yorig, Y)){

        printf("\nChangement après Restore\n");
      }*/

		/************** BEGIN Sample D,S **************/
		//sum C = \alpha op(A) op(B) + \beta C
		//int gsl_blas_dgemm (TransA, TransB, alpha, A, B, beta, C)
		gsl_matrix* X_k= gsl_matrix_alloc(P,N); // free apres sampling gammaY
		gsl_matrix_memcpy(X_k,Y);
		gsl_blas_dgemm(CblasNoTrans, CblasNoTrans, -1.0, hD, W, 1.0, X_k); //X_k = Y - Yflag.*(D*W);
		gsl_matrix_mul_elements (X_k,Yflag);


		if (UpdateOption==1)
		{ // Update block D, then S
			for (k=0;k<K;k++){
        //printf("tracesquare(hD)=%f \n",matrix_square_trace(hD) );
        //printf("tracesquare(W)=%f \n",matrix_square_trace(W) );
				viewsizeN=gsl_matrix_row(W,k); //wk courant
				viewsizeP=gsl_matrix_column(hD,k); //dk courant
				gsl_vector* index = vector_find( &viewsizeN.vector, E_DIF , 0.0 );

				if( index != NULL ) {
					gsl_matrix* Xk_sub=  gsl_matrix_calloc(P, index->size); //M: Px nb i use k
					gsl_matrix* Yf_sub=  gsl_matrix_calloc(P, index->size);
					gsl_vector* wk_sub= gsl_vector_calloc(index->size); //v: nb i use k
					Extrait_User_Of_k(Xk_sub, Yf_sub, wk_sub,
							X_k, &viewsizeN.vector, index);
          /*printf("hD %zu = ",k);
          for (l=0;l<10;l++){
            printf("%f ", gsl_vector_get(&viewsizeP.vector,l) );
          }
          printf("\n ");*/
					// A = \alpha x y^T + A of the matrix A.
					//gsl_blas_dger (double alpha, const gsl_vector * x, const gsl_vector * y, gsl_matrix * A)
					//Xk_sub=  Xk_sub+ Yf_sub.*(D(:,k)*wk);
					gsl_blas_dger(1.0, &viewsizeP.vector, wk_sub,  Xk_sub);//Xk_sub=  Xk_sub+ (D(:,k)*wk);
					gsl_matrix_mul_elements (Xk_sub,Yf_sub); //Xk_sub=  Xk_sub.*Yf_sub;

					gsl_vector *dk = SampleDk(r,Yf_sub, Xk_sub, wk_sub , gammaY);
					gsl_vector_memcpy (&viewsizeP.vector , dk);
				/*	printf("d%zu = ",k);
          for (l=0;l<10;l++){
            printf("%f ", gsl_vector_get(dk,l) );
          }
          printf("\n ");
          */
					//&viewsizeP.vector = SampleDk(Yf_sub, Xk_sub, wk_sub , gammaY);

					//A = \alpha x y^T + A of the matrix A.
					gsl_blas_dger(-1.0, dk, wk_sub,  Xk_sub);//Xk_sub=  Xk_sub - (D(:,k)*wk);
          gsl_matrix_mul_elements (Xk_sub,Yf_sub); //Xk_sub=  Xk_sub.*Yf_sub;

					Copy_SubMatrix( X_k, Xk_sub, index);
          gsl_vector_free(dk);
					gsl_matrix_free(Xk_sub);
					gsl_matrix_free(Yf_sub);
					gsl_vector_free(wk_sub);
					

				}
				gsl_vector_free(index);
          //printf("tracesquare(hD)=%f \n",matrix_square_trace(hD) );
          //printf("tracesquare(W)=%f \n",matrix_square_trace(W) );
         /* printf("hD %zu = ",k);
          for (l=0;l<10;l++){
            printf("%f ", gsl_matrix_get(hD,l,k) );
          }
          printf("\n ");
          getchar();
          */
			}
          //printf("On sample S" );
			for (k=0;k<K;k++)
			{
        /*printf("tracesquare(hD)=%f \n",matrix_square_trace(hD) );
        printf("tracesquare(W)=%f \n",matrix_square_trace(W) );*/
				viewsizeN=gsl_matrix_row(W,k); //wk courant
				viewsizeP=gsl_matrix_column(hD,k); //dk courant
				gsl_vector* index = vector_find( &viewsizeN.vector, E_DIF , 0.0 );

				if( index != NULL ) {
					
					gsl_matrix* Xk_sub=  gsl_matrix_alloc(P, index->size); //M: Px nb i use k
					gsl_matrix* Yf_sub=  gsl_matrix_alloc(P, index->size);
					gsl_vector* wk_sub= gsl_vector_alloc(index->size); //v: nb i use k
					Extrait_User_Of_k(Xk_sub, Yf_sub, wk_sub,
							X_k, &viewsizeN.vector, index);

					// A = \alpha x y^T + A of the matrix A.
					//gsl_blas_dger (double alpha, const gsl_vector * x, const gsl_vector * y, gsl_matrix * A)
					//Xk_sub=  Xk_sub+ Yf_sub.*(D(:,k)*wk);
					gsl_blas_dger(1.0, &viewsizeP.vector, wk_sub,  Xk_sub);//Xk_sub=  Xk_sub+ (D(:,k)*wk);

					gsl_matrix_mul_elements (Xk_sub,Yf_sub); //Xk_sub=  Xk_sub.*Yf_sub;

					gsl_vector* sk_sub = SampleSk(r,Yf_sub, Xk_sub, wk_sub->size , &viewsizeP.vector, gammaY, gammaS);

					//A = \alpha x y^T + A of the matrix A.
					gsl_blas_dger(-1.0, &viewsizeP.vector, sk_sub,  Xk_sub);//Xk_sub=  Xk_sub - (D(:,k)*wk);
          gsl_matrix_mul_elements (Xk_sub,Yf_sub); //Xk_sub=  Xk_sub.*Yf_sub;

					Copy_2SubMatrix(X_k, W, Xk_sub , sk_sub, index,  k);


					gsl_matrix_free(Xk_sub);
					gsl_matrix_free(Yf_sub);
					gsl_vector_free(wk_sub);
					gsl_vector_free(sk_sub);
					
				}
				gsl_vector_free(index);
          /*printf("tracesquare(hD)=%f \n",matrix_square_trace(hD) );
          printf("tracesquare(W)=%f \n",matrix_square_trace(W) );*/
			}
		}
		else{ // 2 : Update mixe dk, sk 
			for (k=0;k<K;k++){
				viewsizeN=gsl_matrix_row(W,k); //wk courant
				viewsizeP=gsl_matrix_column(hD,k); //dk courant
				gsl_vector* index = vector_find( &viewsizeN.vector, E_DIF , 0.0 );

				if( index != NULL ) {
					
					gsl_matrix* Xk_sub=  gsl_matrix_alloc(P, index->size); //M: Px nb i use k
					gsl_matrix* Yf_sub=  gsl_matrix_alloc(P, index->size);
					gsl_vector* wk_sub= gsl_vector_alloc(index->size); //v: nb i use k
					Extrait_User_Of_k(Xk_sub, Yf_sub, wk_sub,
							X_k, &viewsizeN.vector, index);

					// A = \alpha x y^T + A of the matrix A.
					//gsl_blas_dger (double alpha, const gsl_vector * x, const gsl_vector * y, gsl_matrix * A)
					//Xk_sub=  Xk_sub+ Yf_sub.*(D(:,k)*wk);
					gsl_blas_dger(1.0, &viewsizeP.vector, wk_sub,  Xk_sub);//Xk_sub=  Xk_sub+ (D(:,k)*wk);
					gsl_matrix_mul_elements (Xk_sub,Yf_sub); //Xk_sub=  Xk_sub.*Yf_sub;

					gsl_vector_memcpy (&viewsizeP.vector , SampleDk(r, Yf_sub, Xk_sub, wk_sub , gammaY));
					//&viewsizeP.vector = SampleDk(Yf_sub, Xk_sub, wk_sub , gammaY);

					gsl_vector* sk = SampleSk(r,Yf_sub, Xk_sub, wk_sub->size , &viewsizeP.vector, gammaY, gammaS);




					//A = \alpha x y^T + A of the matrix A.
					gsl_blas_dger(-1.0, &viewsizeP.vector, sk,  Xk_sub);//Xk_sub=  Xk_sub - (D(:,k)*wk);
          gsl_matrix_mul_elements (Xk_sub,Yf_sub); //Xk_sub=  Xk_sub.*Yf_sub;
          //X_k(:,zk) = X_k(:,zk)- Yflag(:,zk).*(D(:,k)*W(k,zk));
					Copy_2SubMatrix(X_k, W, Xk_sub , sk, index,  k);

					gsl_matrix_free(Xk_sub);
					gsl_matrix_free(Yf_sub);
					gsl_vector_free(wk_sub);
					gsl_vector_free(sk);
					
				}
				gsl_vector_free(index);

			}
		}


		/************* FIN Sample D,S **************/

		/************** BEGIN Sample 2 sigma & alpha **************/
   
		if (!gsl_matrix_isnull (W)){
			gammaS = SampleGammaS(r, W,sigmaS,2);
			sigmaS = 1.0/sqrt(gammaS); 

			alpha  = gsl_ran_gamma(r, 1.0+K, 1/(1.0+H_N)) ;
			param= alpha/(double) N; 
		}
		gammaY = SampleGammaY(r,X_k,2); 
		varY=1.0/gammaY;
		/************* FIN Sample 2 sigma & alpha **************/
		gsl_matrix_free(X_k);


		tab_D[*iter]= hD;
    	//tab_W[*iter]= gsl_matrix_alloc(K,N);
    	//gsl_matrix_memcpy(tab_W[*iter], W);
    //  W = W_pointer;
		//tab_W[*iter]= W;
		Alpha[*iter]= alpha;
		SigmaNoise[*iter]= sqrt(varY);
		SigmaCoef[*iter]= sigmaS;
		printf("Iteration: %d, K = %zu, noise= %f, alpha= %f\n", *iter,K, sqrt(varY),alpha);
		//gsl_rng_free (r);

		free(tab_invGD);


		if ( (*iter+1) % args.tmp_save_interval ==0){
			char filename[256];

			if (args.tmp_save_dir)
				mkdir(args.tmp_save_dir, S_IRWXU | S_IRWXG | S_IRWXO );

			if( args.save_tmp_dico && args.tmp_save_dir ) {
				sprintf(filename, "%s/tmp_dico_%d", args.tmp_save_dir, (*iter + 1) );
				save_as_csv(tab_D[*iter], filename);
			} else if (args.dico_file) {
				save_as_csv(tab_D[*iter], args.dico_file);
			}

			if( args.save_tmp_dico && args.tmp_save_dir ) {
				sprintf(filename, "%s/tmp_coeff_%d", args.tmp_save_dir, (*iter + 1) );
				save_as_csv(W, filename);
			} else if (args.dico_file) {
				save_as_csv(W, args.coeff_file);
			}

			if( args.save_tmp_imgs && args.tmp_save_dir ) {
				sprintf(filename, "%s/tmp_out_%d.png", args.tmp_save_dir, (*iter + 1) );
				write_png_from_dico_and_coeff(W, tab_D[*iter],
											  args.img_w, args.img_h,
											  args.patch_w, args.patch_h, args.step,
											  filename);
			} else if (args.dico_file) {
				write_png_from_dico_and_coeff(W, tab_D[*iter],
											  args.img_w, args.img_h,
											  args.patch_w, args.patch_h, args.step,
											  args.output_file);
			}
		}


		(*iter) ++; // t=t+1; %s

		
	}//end while
	//gsl_matrix_memcpy(tab_D[*iter], hD);
	*Coef=gsl_matrix_alloc(W->size1,W->size2);
	gsl_matrix_memcpy(*Coef, W);
	gsl_matrix_free(W);
	gsl_matrix_free(M_k_i);
	//gsl_matrix_free(hD);
	gsl_vector_free(nb_pixelActif);
  	gsl_rng_free(r);
	for(i = 0 ; i < P; i++)
		gsl_vector_free(indexs_actif[i]);
	free(indexs_actif);
}
