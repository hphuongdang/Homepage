#include <stdio.h>    
#include <png.h>
#include <math.h>                                                          
#include <gsl/gsl_matrix.h>    
#include <gsl/gsl_vector.h>                                                    
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_blas.h>
#include <string.h>
#include "utils.h"

/* sum (1/i)  avec i=1 to N*/
double sum1divifrom1toN(size_t N){
    double H_N=0.0;
    for (size_t i=1; i<=N; i++){
        H_N += 1.0/ (double)i;
    }
    return H_N;

}


gsl_matrix *poissonrnd(gsl_rng *r, double lambda, size_t nb_lignes, size_t nb_colonnes) {
    size_t i, j;



    //gsl_rng *r = gsl_rng_alloc(gsl_rng_mt19937);
    gsl_matrix *M = NULL;

    M = gsl_matrix_alloc(nb_lignes, nb_colonnes);

    for(i = 0; i < nb_lignes; i++) {                                            
        for(j = 0; j < nb_colonnes; j++) {                                      
            gsl_matrix_set(M, i, j, gsl_ran_poisson(r,lambda));
        }                                                                       
    }                                                                           



    return M;
}

gsl_matrix *randn(gsl_rng *r,double sigma, size_t nb_lignes, size_t nb_colonnes) {
    size_t i, j;

    gsl_matrix *M = NULL;
    //gsl_rng *r = gsl_rng_alloc(gsl_rng_mt19937);
    M = gsl_matrix_alloc(nb_lignes, nb_colonnes);

    for(i = 0; i < nb_lignes; i++) {                                            
        for(j = 0; j < nb_colonnes; j++) {                                      
            gsl_matrix_set(M, i, j, gsl_ran_gaussian(r,sigma));                 
        }                                                                       
    }                                                                           



    return M;
}

gsl_vector *randn_vect(gsl_rng *r, double sigma, size_t nb) {
    size_t i;
    //gsl_rng * r;
    //const gsl_rng_type * T;

    //gsl_rng_env_setup();

    //T = gsl_rng_default;
    //r = gsl_rng_alloc (T);
    gsl_vector *m = NULL;
    //gsl_rng *r = gsl_rng_alloc(gsl_rng_mt19937);
    m = gsl_vector_alloc(nb);

    for(i = 0; i < nb; i++) {                                                                                 
        gsl_vector_set(m, i, gsl_ran_gaussian(r,sigma));                                                                                      
    }                                                                           

   // gsl_rng_free(r);

    return m;
}


gsl_vector *sumMatrix(gsl_matrix* M, int option) {        
    size_t L = M->size1;
    size_t C = M->size2;
    double sum;
    gsl_vector *v = NULL;
    size_t l,c;

    switch(option) // x doit obligatoirement être un entier, les printf sont des exemples d'instructions
    {
        case 1: 
            v=gsl_vector_alloc(C);
            for (c = 0; c < C; c++) {
                sum=0.0;
                for (l = 0; l < L; l++) {
                    sum += gsl_matrix_get(M, l, c);
                }
                gsl_vector_set(v, c, sum);
            }
            break;

        case 2: 
            v=gsl_vector_alloc(L);
            for (l = 0; l < L; l++) {
                sum=0.0;
                for (c = 0; c < C; c++) {
                    sum += gsl_matrix_get(M, l, c);

                }
                gsl_vector_set(v, l, sum);
            }
            break;
        default:
            printf("Warning option !!!!! juste 1 or 2\n");
            break;
    }                                                           

    return v;                                                                   
}   

double sumAllMatrix(gsl_matrix* M) {        
    size_t L = M->size1;
    size_t C = M->size2;
    double sum=0.0;
    size_t l,c;
    for (c = 0; c < C; c++) {
        for (l = 0; l < L; l++) {
            sum += gsl_matrix_get(M, l, c);
        }
    }
 
    return sum;                                                                   
} 



gsl_vector *sumLogicalMatrix(gsl_matrix* M, int option) {        
    size_t L = M->size1;
    size_t C = M->size2;
    int sum;
    gsl_vector *v = NULL;
    size_t l,c;

    switch(option) // x doit obligatoirement être un entier, les printf sont des exemples d'instructions
    {
        case 1: 
            v=gsl_vector_alloc(C);
            for (c = 0; c < C; c++) {
                sum=0;
                for (l = 0; l < L; l++) {
                    if( gsl_matrix_get(M, l, c) != 0.0 ){
                        sum++;
                    }
                }
                gsl_vector_set(v, c, (double) sum);
            }
            break;

        case 2: 
            v=gsl_vector_alloc(L);
            for (l = 0; l < L; l++) {
                sum=0;
                for (c = 0; c < C; c++) {
                    if( gsl_matrix_get(M, l, c) != 0.0 ){
                        sum++;
                    }

                }
                gsl_vector_set(v, l, (double) sum);
            }
            break;
        default:
            printf("Warning option !!!!! juste 1 or 2\n");
            break;
    }                                                           

    return v;                                                                   
} 


gsl_vector* sumLogicalMatrix_FindNNZ(gsl_matrix* M, int option) {        
    size_t L = M->size1;
    size_t C = M->size2;
    int sum;
    double *indexNNZ = NULL;
    size_t nbNNZ = 0;
    size_t l,c;
    gsl_vector* v=NULL;

    switch(option) // x doit obligatoirement être un entier, les printf sont des exemples d'instructions
    {
        case 1: 

            indexNNZ = (double *)malloc(C* sizeof(double) );
            for (c = 0; c < C; c++) {
                sum=0;
                for (l = 0; l < L; l++) {
                    if( gsl_matrix_get(M, l, c) != 0.0 ){
                        sum++;
                    }
                }
                if (sum >0){
                    indexNNZ[nbNNZ++]= (double) c; 
                }

            }
            break;

        case 2: 

            indexNNZ = (double *)malloc(L* sizeof(double) );
            for (l = 0; l < L; l++) {
                sum=0;
                for (c = 0; c < C; c++) {
                    if( gsl_matrix_get(M, l, c) != 0.0 ){
                        sum++;
                    }
                }
                if (sum >0){
                    indexNNZ[nbNNZ++]= (double) l; 
                }

            }
            break;
        default:
            printf("Warning option !!!!! juste 1 or 2\n");
            break;
    }          


    if (nbNNZ>0){
        v = gsl_vector_alloc(nbNNZ);
        for (c = 0; c < nbNNZ; c++)
            gsl_vector_set(v,c, indexNNZ[c]);
    }
    free(indexNNZ);
    return v;

} 






gsl_vector *sumLogicalMatrixExceptOne(gsl_matrix* M, int option,size_t i) {        
    size_t L = M->size1;
    size_t C = M->size2;
    int sum;
    gsl_vector *v = NULL;
    size_t l,c;

    switch(option) // x doit obligatoirement être un entier, les printf sont des exemples d'instructions
    {
        case 1: 
            v=gsl_vector_alloc(C);
            for (c = 0; c < C; c++) {
                sum=0;
                for (l = 0; l < i; l++) {
                    if( gsl_matrix_get(M, l, c) != 0.0 ){
                        sum++;
                    }
                }
                //gsl_vector_set(v, c, sum);
                for (l = i+1; l < L; l++) {
                    if( gsl_matrix_get(M, l, c) != 0.0 ){
                        sum++;
                    }
                }
                gsl_vector_set(v, c, sum);
            }
            break;

        case 2: 
            v=gsl_vector_alloc(L);
            for (l = 0; l < L; l++) {
                sum=0;
                for (c = 0; c < i; c++) {
                    if( gsl_matrix_get(M, l, c) != 0.0 ){
                        sum++;
                    }
                }
                for (c = i+1; c < C; c++) {
                    if( gsl_matrix_get(M, l, c) != 0.0 ){
                        sum++;
                    }

                }
                gsl_vector_set(v, l, (double)sum);
            }
            break;
        default:
            printf("Warning option !!!!! juste 1 or 2\n");
            break;
    }                                                           

    return v;                                                                   
} 

int nnz_Matrix(gsl_matrix* M){        
    int s=0;
    for (size_t l = 0; l < M->size1; l++) {
        for (size_t c = 0; c < M->size2; c++) {
            if( gsl_matrix_get(M, l, c) != 0.0 ){
                s++;
            }
        }  
    }                                 

    return s;                                                                   
}  

int nnz_Vector(gsl_vector* m){        
    int s=0;
    for (size_t l = 0; l < m->size; l++) {
        if(gsl_vector_get(m,l) !=0.0 ){
            s++;
        }
    }                         
    return s;                                                                   
}  



gsl_matrix *matrix_add_rows( gsl_matrix *M, size_t nb_rows  ){
    if ( !M ){
        fprintf(stderr, "gsl_matrix must have already been initialised before adding new rows" );
        return NULL;
    }  

    size_t n = M->tda; /* current number of columns in matrix */

    /* reallocate the memory of the block */
    M->block->data = (double *)realloc(M->block->data, sizeof(double)*(M->block->size + (n * nb_rows)));
    if( !M->block->data ){
        fprintf(stderr, "Could not reallocate memory for gsl_matrix!");
        exit(1);
    }

    memset(&(M->block->data[M->block->size]),0,sizeof(double)*(n*nb_rows));
    M->block->size += (n * nb_rows);      /* update block size (number of elements) */
    M->size1=M->size1+nb_rows;               /* update number of rows */
    M->data = M->block->data; /* point data to block->data */
    return M;
}

gsl_matrix *matrix_Extract_columns( gsl_matrix *M, gsl_vector* index  ){

    gsl_matrix *Msub = gsl_matrix_alloc(M->size1, index->size);
    gsl_vector_view v;
    for(size_t i=0; i<index->size; i++){
        v=gsl_matrix_column(M,  (size_t) gsl_vector_get(index,i));
        gsl_matrix_set_col(Msub, i, &v.vector);
    }
    return Msub;
}

gsl_matrix *matrix_Extract_rows( gsl_matrix *M, gsl_vector* index  ){

    gsl_matrix *Msub = gsl_matrix_alloc( index->size, M->size2);
    gsl_vector_view view_v;
    for(size_t i=0; i<index->size; i++){
        view_v=gsl_matrix_row(M,  (size_t) gsl_vector_get(index,i));
        gsl_matrix_set_row(Msub, i, &view_v.vector);
    }
    return Msub;

}


gsl_vector *vector_Extract( gsl_vector *m, gsl_vector* index  ){

    gsl_vector *msub = gsl_vector_alloc(index->size);
    for(size_t i=0; i<index->size; i++){

        gsl_vector_set(msub, i, gsl_vector_get(m,  gsl_vector_get(index,i)) );
    }
    return msub;

}


gsl_vector *vector_find( gsl_vector *m, int option, double a ){

    double *data = (double *)malloc(m->size * sizeof(double) );
    size_t nb_elem = 0;
    size_t i = 0;
    gsl_vector *v = NULL;

    switch(option) {
        case E_INF:       
            for(i=0; i<m->size; i++){
                if ( gsl_vector_get(m,i) < a){
                    data[nb_elem++] = (double) i;
                }
            }    
            break;

        case E_INFEQ: 
            for(i=0; i<m->size; i++){
                if ( gsl_vector_get(m,i) <= a){
                    data[nb_elem++] = (double) i;
                }
            } 
            break;

        case E_EQ: 
            for(i=0; i<m->size; i++){
                if ( gsl_vector_get(m,i) == a){
                    data[nb_elem++] = (double) i;
                }

            }
            break;

        case E_SUPEQ: 
            for(i=0; i<m->size; i++){
                if ( gsl_vector_get(m,i) >=a){
                    data[nb_elem++] = (double) i;
                }

            } 
            break;

        case E_SUP: 
            for(i=0; i<m->size; i++){
                if ( gsl_vector_get(m,i) >a){
                    data[nb_elem++] = (double) i;
                }
            }
            break;

        case E_DIF: 
            for(i=0; i<m->size; i++){
                if ( gsl_vector_get(m,i) != a){
                    data[nb_elem++] = (double) i;
                }
            }
            break;  


        default:
            printf("Warning option !!!!! E_INF:< / E_INFEQ:<= / E_EQ:== / E_SUPEQ:>= / E_SUP:> / E_DIF: !=  \n");     
            break;
    }           


    //printf("%zu elems found\n", nb_elem);
    if (nb_elem>0){
        v = gsl_vector_alloc(nb_elem);
        for (i = 0; i < nb_elem; i++)
            gsl_vector_set(v,i, data[i]);
    }
    free(data);
    return v;

}


gsl_vector *vector_find_Extract( gsl_vector *m, gsl_vector *mEx, int option, double a ){

    double *data = (double *)malloc(m->size * sizeof(double) );
    size_t nb_elem = 0;
    size_t i = 0;
    gsl_vector *v = NULL;

    switch(option) {
        case E_INF:       
            for(i=0; i<m->size; i++){
                if ( gsl_vector_get(m,i) < a){
                    data[nb_elem++] = gsl_vector_get(mEx,i);
                }
            }    
            break;

        case E_INFEQ: 
            for(i=0; i<m->size; i++){
                if ( gsl_vector_get(m,i) <= a){
                    data[nb_elem++] = gsl_vector_get(mEx,i);
                }
            } 
            break;

        case E_EQ: 
            for(i=0; i<m->size; i++){
                if ( gsl_vector_get(m,i) == a){
                    data[nb_elem++] = gsl_vector_get(mEx,i);
                }

            }
            break;

        case E_SUPEQ: 
            for(i=0; i<m->size; i++){
                if ( gsl_vector_get(m,i) >=a){
                    data[nb_elem++] = gsl_vector_get(mEx,i);
                }

            } 
            break;

        case E_SUP: 
            for(i=0; i<m->size; i++){
                if ( gsl_vector_get(m,i) >a){
                    data[nb_elem++] = gsl_vector_get(mEx,i);
                }
            } 
            break;   

        case E_DIF: 
            for(i=0; i<m->size; i++){
                if ( gsl_vector_get(m,i) != a){
                    data[nb_elem++] = gsl_vector_get(mEx,i);
                }
            } 
            break;  



        default:
            printf("Warning option !!!!! E_INF:< / E_INFEQ:<= / E_EQ:== / E_SUPEQ:>= / E_SUP:> / E_DIF: != \n");

            break;
    }           


    //printf("%zu elems found\n", nb_elem);

    if (nb_elem>0){
        v = gsl_vector_alloc(nb_elem);
        for (i = 0; i < nb_elem; i++)
            gsl_vector_set(v,i, data[i]);
    }
    free(data);
    return v;
}


gsl_matrix *matrix_inverse( gsl_matrix* M){

    gsl_matrix* invM=gsl_matrix_alloc(M->size1,M->size1);
    int s; //// je sais pas c'est quoi mais tout le monde faire ça avec un & après
    gsl_permutation * p = gsl_permutation_alloc (M->size1);
    gsl_linalg_LU_decomp (M, p, &s);    
    gsl_linalg_LU_invert (M, p, invM);

    gsl_permutation_free (p);
    return invM;
}

double matrix_trace( gsl_matrix* M){
    double trace=0.0;

    //size_t L = M->size1;
    //size_t C = M->size2;
    //size_t l,c;
    for (size_t diag = 0; diag < M->size1; diag++) {
        //for (l = 0; l < L; l++) {
            trace += gsl_matrix_get(M, diag, diag) ;
        //}
    }

    return trace;
}

double matrix_square_trace( gsl_matrix* M){
    double trace=0.0;

    size_t L = M->size1;
    size_t C = M->size2;
    size_t l,c;
    for (c = 0; c < C; c++) {
        for (l = 0; l < L; l++) {
            trace += ( gsl_matrix_get(M, l, c)*gsl_matrix_get(M, l, c) ) ;
        }
    }

    return trace;
}

/* 
   C code for reading in a csv file
 */
gsl_matrix *readMatrix(const char *filename) {

    int line_length = 5000000;    
    int nrows, ncols;
    FILE* f;  
    char *pch;
    char *line  = malloc(line_length * sizeof(char));
    gsl_matrix *particles;
    f = fopen(filename, "r");
    
    if(NULL==f) {
        fprintf(stderr, "Cannot open file %s\n", filename);
        exit(1);
    }
    
    nrows = 0; ncols = 0;
    
    /* Scan once to get the dimensions
     * there doesn't seem to be a realloc matrix function
    */

    while(fgets(line, line_length, f) != NULL) {
        pch = strtok(line,",");
        while(nrows == 0 && pch != NULL ) {
            ncols++;
            pch = strtok(NULL,",");
        }
        nrows++;
    }

    fclose(f);
    //printf("Nrow : %d Ncol : %d\n", nrows, ncols);

    /*Create matrix and fill up*/
    particles = gsl_matrix_alloc(nrows, ncols);
    nrows = 0; ncols = 0;
    f=fopen(filename, "r");
    while(fgets(line, line_length, f) != NULL){
        pch = strtok(line,",");
        while(pch != NULL ) {
            gsl_matrix_set(particles, nrows, ncols, atof(pch));
            ncols++;
            pch = strtok(NULL,",");
        }
        ncols = 0;
        nrows++;
    }
    fclose(f);
  	free(line); 
    return(particles);    
}  


int save_as_csv(gsl_matrix * M, char *filename) {

    FILE *fp;
	char *fullname = malloc( (strlen(filename) + 5) * sizeof(char));
	strncpy(fullname, filename, strlen(filename) + 1);
    fullname = strcat(fullname, ".csv");

    fp=fopen(fullname,"w+");

	if(fp){
		for (size_t i = 0; i < M->size1; i++) {
			for (size_t j = 0; j < M->size2; j++) {
				fprintf(fp, "%f", gsl_matrix_get (M, i, j));
				if (j < M->size2 - 1)
					fprintf(fp, ",");
			}
			fprintf(fp, "\n");
		}
		fclose(fp);
	}else{
		printf("Error opening %s\n", fullname);
	}
	free(fullname);
    return 0;
}

gsl_matrix *matrix_add_cols( gsl_matrix *M, size_t nb_cols  ){
    gsl_matrix *Mtmp = gsl_matrix_alloc(M->size1,M->size2 + nb_cols);

    for (size_t col=0; col<M->size2; col++){
		for (size_t l=0; l < M->size1; l++){
			gsl_matrix_set(Mtmp, l, col, gsl_matrix_get(M, l, col));
		}
    }

    gsl_matrix_free(M);
    return Mtmp;
}

void matrix_print(gsl_matrix *M){
    for (size_t i = 0; i < M->size1; ++i)
         for (size_t j = 0; j < M->size2; ++j)
             printf(j==(M->size2-1)?"%6.3f\n":"%6.3f ",gsl_matrix_get(M,i,j));

}

void vector_print(gsl_vector *v){
    for (size_t i = 0; i < v->size; ++i){
             printf("%f ",gsl_vector_get(v,i));
         }
         printf("\n");

}

gsl_matrix *reconstitute_img_matrix(gsl_matrix *Y_result,
										   int width,
										   int height,
										   int patch_w,
										   int patch_h,
										   int step) {
	gsl_matrix *image = gsl_matrix_calloc(width, height);
	gsl_matrix *weights = gsl_matrix_calloc(width, height);
	double buf;

	int yl, yc, il, ic;
	int off_l = 0, off_c = 0;
	for ( yc = 0; yc < Y_result->size2; yc++ ) {
		for( yl = 0; yl < Y_result->size1; yl++ ) {
			ic = (yl / patch_h) + off_c;
			il = (yl % patch_h) + off_l;
			//printf("ic : %d, il : %d, yc : %d, yl : %d\n", ic, il, yc, yl);
			buf = gsl_matrix_get(image, il, ic);
			buf += gsl_matrix_get(Y_result, yl, yc);
			gsl_matrix_set(image, il, ic, buf);

			buf = gsl_matrix_get(weights, il, ic);
			gsl_matrix_set(weights, il, ic, buf + 1);
		}

		off_l += step;
		if ( off_l > (width - patch_h) ) {
			off_l = 0;
			off_c += step;
		}
	}
	
	for(il = 0; il < image->size1; il++) {
		for(ic = 0; ic < image->size2; ic++) {
			buf = gsl_matrix_get(image, il, ic);
			gsl_matrix_set(image, il, ic, (buf / gsl_matrix_get(weights, il, ic)) * 255);
		}
	}

	gsl_matrix_free(weights);
	
	return image;
}

void export_to_rgb_png(gsl_matrix *r, gsl_matrix *g, gsl_matrix *b, const char *path) {
	int width = r->size2;
	int height = r->size1;

	/* create file */
	FILE *fp = fopen(path, "wb+");
	png_structp png_ptr;
	png_infop info_ptr;

	png_bytep * row_pointers = malloc(height * sizeof(png_byte *));
	int l,c;
	for(l = 0; l < height; l++) {
		row_pointers[l] = malloc( 3 * width * sizeof(png_byte));
		for(c = 0; c < width; c++) {
			row_pointers[l][3*c] = (char)gsl_matrix_get(r, l, c);
			row_pointers[l][3*c+1] = (char)gsl_matrix_get(g, l, c);
			row_pointers[l][3*c+2] = (char)gsl_matrix_get(b, l, c);
		}
	}

	if (!fp)
		printf("Cannot open %s\n", path);

	/* initialize stuff */
	png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);

	if (!png_ptr)
		printf("Cannot create png struct\n");

	info_ptr = png_create_info_struct(png_ptr);
	if (!info_ptr)
		printf("Cannot create info struct\n");

	if (setjmp(png_jmpbuf(png_ptr))){
		printf("Error during init_io\n");
	}else{
		png_init_io(png_ptr, fp);
	}

	/* write header */
	if (setjmp(png_jmpbuf(png_ptr)))
		printf("Error during writing header\n");
	else
		png_set_IHDR(png_ptr, info_ptr, width, height,
				 8, PNG_COLOR_TYPE_RGB, PNG_INTERLACE_NONE,
				 PNG_COMPRESSION_TYPE_BASE, PNG_FILTER_TYPE_BASE);

	png_write_info(png_ptr, info_ptr);

	/* write bytes */
	if (setjmp(png_jmpbuf(png_ptr)))
		printf("Error during writing bytes\n");
	else
		png_write_image(png_ptr, row_pointers);


	/* end write */
	if (setjmp(png_jmpbuf(png_ptr)))
		printf("[write_png_file] Error during end of write");
	else
		png_write_end(png_ptr, NULL);

	/* cleanup heap allocation */
	for (l=0; l<height; l++)
		free(row_pointers[l]);
	free(row_pointers);

	png_destroy_write_struct(&png_ptr, &info_ptr);
	fclose(fp);
}
void export_to_png(gsl_matrix *M, const char *path) {
	int width = M->size2;
	int height = M->size1;

	/* create file */
	FILE *fp = fopen(path, "wb+");
	png_structp png_ptr;
	png_infop info_ptr;

	png_bytep * row_pointers = malloc(height * sizeof(png_byte *));
	int l,c;
	for(l = 0; l < height; l++) {
		row_pointers[l] = malloc(width * sizeof(png_byte));
		for(c = 0; c < width; c++) {
			row_pointers[l][c] = (char)gsl_matrix_get(M, l, c);
		}
	}

	if (!fp)
		printf("Cannot open %s\n", path);

	/* initialize stuff */
	png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);

	if (!png_ptr)
		printf("Cannot create png struct\n");

	info_ptr = png_create_info_struct(png_ptr);
	if (!info_ptr)
		printf("Cannot create info struct\n");

	if (setjmp(png_jmpbuf(png_ptr))){
		printf("Error during init_io\n");
	}else{
		png_init_io(png_ptr, fp);
	}

	/* write header */
	if (setjmp(png_jmpbuf(png_ptr)))
		printf("Error during writing header\n");
	else
		png_set_IHDR(png_ptr, info_ptr, width, height,
				 8, PNG_COLOR_TYPE_GRAY, PNG_INTERLACE_NONE,
				 PNG_COMPRESSION_TYPE_BASE, PNG_FILTER_TYPE_BASE);

	png_write_info(png_ptr, info_ptr);

	/* write bytes */
	if (setjmp(png_jmpbuf(png_ptr)))
		printf("Error during writing bytes\n");
	else
		png_write_image(png_ptr, row_pointers);


	/* end write */
	if (setjmp(png_jmpbuf(png_ptr)))
		printf("[write_png_file] Error during end of write");
	else
		png_write_end(png_ptr, NULL);

	/* cleanup heap allocation */
	for (l=0; l<height; l++)
		free(row_pointers[l]);
	free(row_pointers);

	png_destroy_write_struct(&png_ptr, &info_ptr);
	fclose(fp);
}

void write_png_from_dico_and_coeff(gsl_matrix *C, gsl_matrix *D,
								   int width, int height,
								   int patch_w, int patch_h, int step,
								   const char *output_file) {
	// First, get Yre = D * C
	gsl_matrix *Y_result = gsl_matrix_alloc(D->size1, C->size2);

	gsl_blas_dgemm(CblasNoTrans, CblasNoTrans, 1.0, D, C, 1.0, Y_result);

	gsl_matrix *image = reconstitute_img_matrix(Y_result, width, height, patch_w, patch_h, step);

	export_to_png(image, output_file);

	gsl_matrix_free(image);
	gsl_matrix_free(Y_result);
}

gsl_matrix **read_png( const char *filename ) {
	unsigned char header[8];    // 8 is the maximum size that can be checked
	png_structp png_ptr;
	png_infop info_ptr;
	gsl_matrix **img;
	int width, height;
	png_byte color_type;
	png_byte bit_depth;
	png_bytep * row_pointers;
	int y;

	FILE *fp = fopen(filename, "rb");
	if (!fp) {
		printf("cannot open %s\n", filename);
		return NULL;
	}

	if( !fread(header, 1, 8, fp) )
		printf("Err reading header\n");

	if (png_sig_cmp(header, 0, 8)) {
		printf("File %s is not recognized as a PNG file\n", filename);
		return NULL;
	}

	/* initialize stuff */
	png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);

	info_ptr = png_create_info_struct(png_ptr);

	if (setjmp(png_jmpbuf(png_ptr))) {
		printf("Error during init_io\n");
	} else {
		png_init_io(png_ptr, fp);
	}

	png_set_sig_bytes(png_ptr, 8);

	png_read_info(png_ptr, info_ptr);

	width = png_get_image_width(png_ptr, info_ptr);
	height = png_get_image_height(png_ptr, info_ptr);

	color_type = png_get_color_type(png_ptr, info_ptr);
	bit_depth = png_get_bit_depth(png_ptr, info_ptr);

	// Transform the image to a canonical form :
	// if gray, set it to grayscale 8bit no alpha
	if( color_type & PNG_COLOR_MASK_ALPHA )
		png_set_strip_alpha(png_ptr);	

	if( color_type & PNG_COLOR_MASK_PALETTE )
		png_set_palette_to_rgb(png_ptr);

	// more than 8bit depth ?
	if( bit_depth == 16 )
		png_set_strip_16(png_ptr);

	// less than 8bit depth ? ( grayscale only )
//	if( bit_depth < 8 && color_type == PNG_COLOR_TYPE_GRAY )
//		png_set_gray_1_2_4_to_8(png_ptr);


	png_read_update_info(png_ptr, info_ptr);

	/* read file */
	if (setjmp(png_jmpbuf(png_ptr))) {
		printf("Error during read_image\n");
		return NULL;
	} else {

		row_pointers = (png_bytep*) malloc(sizeof(png_bytep) * height);

		for (y=0; y<height; y++)
			row_pointers[y] = (png_byte*) malloc(png_get_rowbytes(png_ptr,info_ptr));

		png_read_image(png_ptr, row_pointers);
		
	}
	fclose(fp);
	
	
	img = malloc( 3 * sizeof(gsl_matrix *));
	img[0] = NULL; img[1] = NULL; img[2] = NULL;

	if( color_type & PNG_COLOR_MASK_COLOR ) {
		for (y = 0; y < 3; y++) {
			img[y] = gsl_matrix_calloc(height, width);
		}
	} else {
		img[0] = gsl_matrix_calloc(height, width);
	}


	int l, c;
	for ( l = 0; l < height; l++ ) {
		for( c = 0; c < width; c++ ) {
			if( color_type & PNG_COLOR_MASK_COLOR ) {
				gsl_matrix_set(img[0], l, c, row_pointers[l][3*c]);
				gsl_matrix_set(img[1], l, c, row_pointers[l][3*c+1]);
				gsl_matrix_set(img[2], l, c, row_pointers[l][3*c+2]);
			} else {
				gsl_matrix_set(img[0], l, c, row_pointers[l][c]);
			}
		}
		free(row_pointers[l]);
	}
	free(row_pointers);
	png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
	
	return img;
}

/** ----------------------------------------------------------------------------
 * returns a matrix of size w x h
 */
gsl_matrix *read_png_gray( const char *filename ) {
	
	gsl_matrix **img_comp = read_png(filename);
	gsl_matrix *img = NULL;
	// if we have more than 1 component, we are not in grayscale.
	if(img_comp[1] || img_comp[2])
		printf("%s not a grayscale image\n", filename);
	else
		img = img_comp[0];
	free(img_comp);

	return img;
}

/** ----------------------------------------------------------------------------
 * img is of size w x h, not in 'patches' format.
 */
gsl_matrix *get_flags_gray( gsl_matrix *img) {
	// Simple heuristics : if pixel if full black, consider it bad.
	gsl_matrix *flag_matrix = gsl_matrix_calloc(img->size1, img->size2);
	int l, c;
	for(l = 0; l < img->size1; l++)
		for(c = 0; c < img->size2; c++)
			if(gsl_matrix_get(img, l, c) != 0.0)
				gsl_matrix_set(flag_matrix, l, c, 255.0);

	return flag_matrix;
}

gsl_matrix *img_to_patches( const gsl_matrix *img,
							int patch_w,
							int patch_h,
							int step ) {
	int f_w, f_h;
	int l, c, lp, cp;

	int flag_c = 0;

	f_w = ( ( (img->size1 - patch_w) / step ) + 1) * ( ( (img->size2 - patch_h) / step ) + 1);
	f_h = patch_w * patch_h;

	printf("f_w : %d, f_h : %d\n", f_w, f_h);

	gsl_matrix *patch = gsl_matrix_alloc(f_h, f_w);

	for(c = 0; c < (img->size2 - patch_w + 1); c += step) {
		for(l = 0; l < (img->size1 - patch_h + 1); l += step) {
			for(cp = 0; cp < patch_w; cp++) {
				for(lp = 0; lp < patch_h; lp++) {
					gsl_matrix_set(patch,
								   cp * patch_h + lp,
								   flag_c,
								   gsl_matrix_get(img, l + lp, c + cp ) / 255.0);
				}
			}
			flag_c++;
		}
	}

	return patch;
}


gsl_matrix* matrix_rescale(gsl_matrix *Im, double a, double b) {

	gsl_matrix* Ire=gsl_matrix_alloc(Im->size1,Im->size2);
	gsl_matrix_memcpy (Ire, Im);
	double min;
	double max;

	gsl_matrix_minmax (Im, &min, &max);
	if ( max - min > 2.2204 * pow(10, -16) ) {
		gsl_matrix_add_constant (Ire,-min);
		gsl_matrix_scale(Ire,(b-a)/(max-min));
		gsl_matrix_add_constant (Ire, a);
	}

	return Ire;
}

