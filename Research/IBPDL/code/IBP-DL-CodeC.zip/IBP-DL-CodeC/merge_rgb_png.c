#include<stdio.h>
#include<stdlib.h>
#include<getopt.h>

#include"utils.h"

static void usage() {
	printf("Convert 3 grayscale PNG into one RGB file\n");
	printf("./split_rgb_png -o output_file\n");
	printf("                -r red_input_file\n");
	printf("                -g green_input_file\n");
	printf("                -b blue_input_file\n");
	exit(1);
}

int main( int argc, char **argv ) {
	char c;
	extern char * optarg; 

	char *output_file = NULL,
		 *red_input_file = NULL,
		 *green_input_file = NULL,
		 *blue_input_file = NULL;

	int rescale = 0;

	while ((c = getopt(argc , argv, "o:r:g:b:R")) != -1) {
		switch(c) {
			case 'o' : output_file = optarg; break;
			case 'r' : red_input_file = optarg; break;
			case 'g' : green_input_file = optarg; break;
			case 'b' : blue_input_file = optarg; break;
			case 'R' : rescale = 1; break;
			default : usage();
		}
	}

	if ( !output_file || !red_input_file  || !green_input_file || !blue_input_file )
		usage();

	gsl_matrix *r, *g, *b;
	gsl_matrix *buff;

	if( rescale ) {

		buff = read_png_gray(red_input_file);
		r = matrix_rescale( buff, 0, 255 );
		gsl_matrix_free(buff);

		buff = read_png_gray(green_input_file);
		g = matrix_rescale( buff, 0, 255 );
		gsl_matrix_free(buff);

		buff = read_png_gray(blue_input_file);
		b = matrix_rescale( buff, 0, 255 );
		gsl_matrix_free(buff);

	} else {

		r = read_png_gray(red_input_file);
		g = read_png_gray(green_input_file);
		b = read_png_gray(blue_input_file);

	}
	if( r->size1 != g->size1 || r->size1 != b->size1 ||
		r->size2 != g->size2 || r->size2 != b->size2 ) {
		printf("Image dimensions must match\n");
		exit(1);
	}

	export_to_rgb_png(r, g, b, output_file);

	gsl_matrix_free(r);
	gsl_matrix_free(g);
	gsl_matrix_free(b);
	
	return 0;
}
